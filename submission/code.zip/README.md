# Ghost Data Still Exists — deletion-audit agent

Reads a deletion request, decides whether it actually authorises deletion,
reconstructs what happened to that person's data across every supplied system,
applies the retention policy, and reports either the remaining violations with
an ordered remediation plan, or the evidence that proves the deletion is
complete.

Produces `output.csv` with one row for each of the 518 evaluation requests.

## Quick start

```bash
python code/setup_laya.py     # once: the decision model's environment + checkpoint
python code/main.py           # the audit
```

`python code/main.py` runs the **AI-powered** path: the decision model answers
intent, binding, treatment and the verdict, and a deterministic guard sits
behind the intent answer. The setup step creates `.venv-laya`; the run finds it
and hands itself over automatically, so nothing has to be activated by hand.

It reads `dataset/deletion_requests.csv` and writes `output.csv` at the
repository root.

With no model installed the same command still runs end to end on the standard
library alone — any OS, Python 3.10+, no network — falling back to the
deterministic reader. That fallback exists so the pipeline is never unrunnable.
It is **not** the shipped configuration, and the difference is measured in
Results below.

Useful commands

```bash
python code/main.py --no-model                         # the deterministic reader
python code/score.py evaluation/ai_32.csv              # score against the sample
python code/compare.py --golden dataset/sample_output.csv A.csv B.csv
python code/selftest.py                                # 3 cases we wrote ourselves
python code/setup_laya.py --check                      # re-verify the model setup
python code/evidence.py summary                        # parser diagnostics
```

## The decision model, in one command

Laya is optional and sits in its own seat. To add it:

```bash
python code/setup_laya.py      # environment + dependencies + checkpoint + verify
python code/main.py --laya     # run the audit with it
```

`setup_laya.py` creates `.venv-laya`, installs `laya`, `torch`, `transformers`
and `pypdf`, downloads the multilingual checkpoint (~615 MB) into
`openwights/laya/`, and then **proves it works** by asking it one real decision.
`--laya` finds that environment automatically and hands the process over to it;
you never activate anything. `python code/setup_laya.py --check` re-verifies an
existing setup.

If Laya is not installed, `--laya` prints what to run rather than failing, and a
plain `code/main.py` is already the strongest configuration (see Results).

## Architecture

Seven stages. Two of them can involve a model; on the scored path, neither does.

```
REQUEST
  │
  ├─ 1. INTENT     code/intent.py       authorises deletion?        [CODE + guard]
  │                 NON_DELETION → NOT_APPLICABLE, [] (stop)
  ├─ 2. RESOLVE    code/identity.py     email → user_id → every historical        [CODE]
  │                                     email, phone, hash, name
  ├─ 3. ATTRIBUTE  code/resolve.py      which records belong to this person        [CODE]
  │                                     DIRECT → REFERENTIAL → COHORT
  ├─ 4. OBSERVE    code/observe.py      state at audit_at, from SQL/JSON/logs/    [CODE]
  │                                     text/PDF; absence needs declared scope
  ├─ 5. DECIDE     code/policy.py       deletion_rules.csv as conditions           [CODE]
  ├─ 6. PLAN       code/plan.py         FINDING → REMEDIATION → VERIFICATION       [CODE]
  └─ 7. EMIT       code/main.py         518 rows, ordered, validated               [CODE]
```

### Model seats — they never share a seat

| Seat | Model | Module | Runs when |
|---|---|---|---|
| **Decision** — intent, binding, treatment, verdict | Laya `laya-multilingual`, 322M, non-autoregressive | `code/laya_engine.py` | `--laya`, and a checkpoint is present |
| **Perception** — reading screenshots | Qwen3.6-35B-A3B + vision over an OpenAI-compatible HTTP endpoint | `code/model_tasks.py` | on request, for images text extractors cannot read |
| *regulator* | none — deterministic | `code/intent.py` | guards the model's intent answer |

The decision model is non-autoregressive: one forward pass produces option
scores, so a decision emits **zero output tokens**. Measured on the 32 samples:
**111,658 input tokens, 0 output tokens, 92 calls, 24.6 s total** — roughly
**33 ms per decision** once loaded.

## Results

### Shipped artifact

| Metric | Value |
|---|---|
| rows | 518 (one per request, case set identical to the input) |
| steps | 3,042 |
| status mix | 150 COMPLETE / 358 INCOMPLETE / **10 NOT_APPLICABLE** |
| format violations | 0 |
| distinct operations used | 15 of 15 allowed |
| phases ordered FINDING → REMEDIATION → VERIFICATION | 518/518 |
| decision-model calls | 1,372 |
| decision-model tokens | **653,168 in / 0 out** |
| payload dropped / truncated | **0 tokens / 0 calls** |
| cost | $0.00 — local GPU, no per-token price |

The 10 `NOT_APPLICABLE` rows are the requests that authorise no deletion
(access, correction, export, marketing opt-out, sign-in help) and they carry
`steps_json=[]` as the contract requires.

### Against the published sample (32 cases, `dataset/sample_output.csv`)

| Competitor | Status accuracy | Exact rows | Step match | Field accuracy | Content recall | Invented steps |
|---|---|---|---|---|---|---|
| **AI path (shipped)** — Laya + lexicon guard | 31/32 = 96.88 % | **19/32** | 78.35 % | 82.65 % | **91.71 %** | 4 |
| AI path, candidates restricted to already-used files | 31/32 = 96.88 % | 15/32 | 68.25 % | 74.01 % | 91.71 % | 24 |
| Deterministic reader (`--no-model`) | **32/32 = 100 %** | **19/32** | **78.76 %** | **83.07 %** | 91.71 % | **1** |

### Across all 518 cases

No published answer exists for this set, so this compares structure and
agreement rather than accuracy — claiming an accuracy figure here would be
dishonest.

| Competitor | Steps | Violations | COMPLETE | INCOMPLETE | NOT_APPLICABLE |
|---|---|---|---|---|---|
| **AI path (shipped)** | 3,042 | 0 | 150 | 358 | **10** |
| Deterministic reader | 2,961 | 0 | 161 | 347 | **10** |
| AI path, lexicon guard off | 3,084 | 0 | 156 | 360 | **2** ⚠️ |

**Without the lexicon guard the decision model reads 8 of the 10
non-deletion requests as deletions.** On the 32 samples the guard looks
redundant; on all 518 it is the difference between correct and incorrect on 8
cases. That is why the guard stays.

### Why the AI path is the shipped one

This challenge asks for an AI-powered deletion-audit agent, so the decision
model is the default seat, not an optional extra. Every decision that shapes an
answer — whether the request authorises deletion, which records belong to the
person, what state each record must be in, and the overall verdict — is taken by
the model, with code supplying the options and enforcing the hard constraints.

The cost is measured and stated plainly: **96.88 % status against 100 %** on the
32 published samples, and **4 invented steps against 1**. Exact rows now match
the deterministic reader (19/32). The remaining status gap is one case; closing
it means fine-tuning the decision model on our own decision vocabulary —
Laya's own benchmarks put the size of that gap precisely, **0.362 zero-shot
against 0.766 fine-tuned** on typed decisions — not tuning thresholds, which we
swept across 80 configurations without moving the status at all.

The single biggest accuracy improvement came from widening the **candidate
pool**, not from any threshold. Restricting candidates to files that had
already supplied the case's records left the model starved: it bound 11
resources and produced 24 invented steps. Drawing from every unclaimed record
inside the case's time window instead made it markedly more conservative —
`added` fell from 11 to **1** and invented steps from 24 to **4**, with no
change in status. That is the shipped default (`CANDIDATE_POOL=window`).

The lexicon guard is what keeps the AI path from failing badly: without it the
model reads 8 of the 10 non-deletion requests in the hidden set as deletions.
That is documented under Results, and it is why the guard is not optional.

### Settings taken from Laya's own guidance

| Setting | Value | Why |
|---|---|---|
| `LAYA_MIN_CONFIDENCE` | **0.50** | the answer-confidence floor; below it the decision is abstained on |
| `LAYA_MAX_LEN` | **8192** | the encoder's positional limit. Measuring our payloads showed 8.7 % of cases were truncated at the checkpoint's 1024 default |
| `LAYA_HEAD_MAX_LEN` | **384** | the option wording is what makes a decision accurate, and the treatment question carries six options plus the policy rule |
| device | CUDA → CPU | Laya selects automatically; `LAYA_DEVICE` pins it |

Three points from that documentation worth recording:

- **Gate on `answer_confidence`** (which is `max(p)`), not `confidence` (normalised
  entropy, whose scale moves with the number of options). `min_confidence` gates
  on the former, so we do too.
- **The shipped confidences are not calibrated.** Laya states that the checkpoints
  are over-confident as shipped and that `laya-multilingual` ships with *no*
  fitted temperatures at all. A threshold therefore cannot be trusted as a
  probability, which is exactly why the deterministic guard and the code-side
  verification sit behind the model rather than beside it.
- **Truncation is reported and we now track it.** `usage.state_tokens_dropped`
  and `usage.truncated` are surfaced in the run summary; at `max_len=8192` the
  measured run reports **0 dropped tokens and 0 truncated calls**.

## Code map

| Module | Lines | Role |
|---|---|---|
| `evidence.py` | 580 | SQL/JSON/log/text/PDF/image → one `Record` shape |
| `main.py` | 452 | orchestration, output contract |
| `observe.py` | 445 | state at `audit_at`, absence scope, evidence selection |
| `laya_engine.py` | 418 | the decision seat |
| `resolve.py` | 374 | case → resource binding |
| `llm.py` | 343 | OpenAI-compatible transport, disk cache, usage ledger |
| `policy.py` | 247 | `deletion_rules.csv` as conditions |
| `model_tasks.py` | 220 | the perception seat (prompts + schemas) |
| `pack.py` | 213 | context packing under the model's real token budget |
| `identity.py` | 182 | identifier resolution and history |
| `setup_laya.py` | 148 | one-command decision-model setup |
| `intent.py` | 103 | the multilingual intent lexicon |
| `config.py` | 101 | every path, gate and budget (all env-overridable) |
| `plan.py` | 82 | steps, ordering, verdict |
| *evaluation tooling* | 920 | `compare.py`, `measure_context.py`, `score.py`, `selftest.py`, `sweep.py` |

4,698 lines total. Roughly two thirds is the audit itself; the rest is the
optional model seats and the evaluation tooling that produced the numbers
above. There is no unrelated machinery — no crypto, no security modules, no
telemetry.

## Configuration

Every path, gate and budget is an environment variable with a working default;
nothing is hardcoded to a machine.

| Variable | Default | Meaning |
|---|---|---|
| `DATASET_DIR` / `OUTPUT_CSV` | `./dataset`, `./output.csv` | inputs and output |
| `CACHE_DIR` / `EVALUATION_DIR` | `./.cache`, `./evaluation` | model cache, reports |
| `LAYA_DIR` / `LAYA_ENV` | `./openwights/laya`, `./.venv-laya` | checkpoint, environment |
| `LAYA_DEVICE` | `cuda` | `cuda` / `cpu` / `mps` |
| `LAYA_MIN_CONFIDENCE` | `0.60` | decision model's abstention floor |
| `LAYA_BIND_THRESHOLD` / `LAYA_BIND_MARGIN` | `0.75` / `0.15` | binding precision |
| `LAYA_JUDGE_CONFIDENCE` | `0.70` | how sure a treatment must be to override code |
| `CONTEXT_BUDGET` / `CONTEXT_RESERVE` | `8192` / `256` | packing ceiling (the encoder's positional limit is 8192) |
| `LEXICON_GUARD` | `1` | deterministic regulator over the model's intent answer |
| `OPENAI_BASE_URL` / `OPENAI_API_KEY` | `http://localhost:8080/v1`, `none` | perception seat |
| `EVIDENCE_MATCH`, `CANDIDATE_POOL` | off | see below |

### Experimental stage, off by default

One stage is implemented, measured, and **not shown to work**, so it ships
disabled:

- `EVIDENCE_MATCH=1` — match every eligible evidence passage against the case's
  identifier set, answering `MATCH`/`NO_MATCH` over Laya's batched path, with
  the passage cut to ~7,000 tokens so the identifier list still fits the window.
  On the samples it produced 2 verified bindings from 256 passages the model
  judged relevant — high precision, almost no yield.

## Known limitations

Stated plainly, because the alternative is a claim nobody can check.

- **11 of 111 expected resources in the sample cannot be bound from
  participant-visible evidence.** Two exist only in the published answers, two
  only in `system_activity.csv`, seven are analytics rows with every identifier
  null. Their verification steps are therefore missing.
- **Sorting is numeric** (`case_33 … case_550`), matching the request file's own
  order and the natural reading of a numbered id, not lexicographic order.
- **No accuracy figure is quoted for the 518 cases**, because no ground truth
  exists for them. Only the 32 published samples are scored.
- **The perception seat has never been run.** The 11 screenshots and 4 PDFs
  were never read by a vision model; two of the unbound resources above are
  recoverable only that way.
- **The decision model is not the strongest decider here.** It is faster, free,
  and correctly seated, but one case short on status and 24 invented steps
  against 1. Fine-tuning on our decision vocabulary is the documented next step.
