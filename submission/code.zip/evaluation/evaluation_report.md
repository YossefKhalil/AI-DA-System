# Evaluation report

## 1. What shipped

`output.csv` is produced by the **AI path**: Laya answers intent, binding,
treatment and the verdict; code supplies the options, verifies every pick, and
supplies a deterministic guard over the intent answer.

```text
requests: 518  steps: 3019
  COMPLETE: 149   INCOMPLETE: 359   NOT_APPLICABLE: 10
```

The 10 `NOT_APPLICABLE` rows are exactly `case_533`-`case_542`, the requests
that authorise no deletion. The guard overrode the model on exactly 10 cases,
and those are the 10.

There is **no published ground truth for the 518 cases**, so no accuracy figure
is claimed for them. Only the 32 public samples are scored.

## 2. Accuracy against the published sample (32 cases)

| Competitor | Status | Exact rows | Step match | Field | Recall | Invented steps |
|---|---|---|---|---|---|---|
| **AI path (shipped)** | 31/32 = 96.88 % | 19/32 | 78.35 % | 82.65 % | 91.71 % | 4 |
| Deterministic reader (`--no-model`) | **32/32 = 100 %** | 19/32 | 78.76 % | 83.07 % | 91.71 % | **1** |

Sequence accuracy, 518 rows: phases non-decreasing on 518/518, `step_no`
contiguous on 518/518, no flow/restore step after a record step, 15 of 15
allowed operations used, 0 format violations.

## 3. Participant-authored evaluation cases

`python code/selftest.py` -> **3/3 pass**, through the real
observe -> policy -> plan path:

1. a tombstone already stripped of name/email/phone/hash verifies `REDACTED`
   (`COMPLETE`), and its stable `user_id` is not mistaken for an identifier;
2. a retained support message still carrying the subject's email is
   `REPORT_EXPOSED_PII` -> `REDACT_RECORD` -> `VERIFY_RECORD_REDACTED`
   (`INCOMPLETE`);
3. a live connector and a restorable backup are both reported, the flow is
   disabled before the restore is blocked, and neither verification cites
   evidence because the work is future.

## 4. Failures found and improvements made

1. **Candidate pool starvation (largest gain).** Restricting candidates to
   files that had already supplied a case's records left the model guessing:
   11 wrong bindings, 24 invented steps. Drawing from every unclaimed record in
   the case's time window made it *more* conservative - `added` fell 11 -> 1,
   invented steps 24 -> 4, exact rows 15 -> 19 of 32, status unchanged.
   Counter-intuitive and measured: more options produced fewer errors.
2. **Silent output overwrite.** The Laya environment hand-off returned a boolean,
   so a child failure made the parent re-run deterministically and overwrite the
   AI output with the worse one. It now propagates the child's exit status.
   This invalidated an earlier comparison, which was corrected rather than kept.
3. **A ledger write could crash a successful run** when the perception endpoint
   was unreachable. Now non-fatal.
4. **Threshold tuning does not work here.** 80 configurations over 16 generations
   produced exactly one status value. The knobs move *which* wrong bindings
   occur, never whether they occur.
5. **Embedding similarity cannot match identifiers.** Measured: two strangers'
   emails score 0.864 cosine while a typo and its correct form score 0.862 -
   different people are *more* similar than the same person corrupted. Usable for
   recall, unusable as a verdict.
6. **Truncation was invisible.** Laya reports `state_tokens_dropped` and
   `truncated`; surfaced now, and at `max_len=8192` the run reports 0 of both,
   against 8.7 % of cases silently truncated at the checkpoint's 1024 default.

## 5. Known gaps

11 of 111 expected sample resources cannot be bound from participant-visible
evidence: two exist only in the published answers, two only in
`system_activity.csv`, seven are analytics rows with every identifier null.
`account_002`/`account_004` are recoverable only by reading the uncited
screenshots, and the perception seat has never executed. The remaining status
gap is a fine-tuning job - Laya's own benchmarks give 0.362 zero-shot against
0.766 fine-tuned - not a settings one.
