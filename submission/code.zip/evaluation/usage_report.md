# Usage report

## 1. The run that produced `output.csv`

```bash
python code/main.py            # decision model on by default
```

```text
requests: 518  steps: 3019
  COMPLETE: 149   INCOMPLETE: 359   NOT_APPLICABLE: 10
```

| Metric | Value |
|---|---|
| decision-model calls | **1,453** |
| input tokens | **1,997,232** |
| output tokens | **0** |
| dropped tokens | 0 |
| truncated calls | 0 |
| perception-model calls | 0 |
| cost | **$0.00** ? local GPU, no per-token price |

Laya is non-autoregressive: a decision is one forward pass over the options, so
the output side is structurally zero. Input tokens are what the model reports,
falling back to the payload actually sent; the run reported every call, so
nothing here is estimated.

## 2. Providers and model seats

| Seat | Model | Module |
|---|---|---|
| Decision | Laya `laya-multilingual`, 322M, non-autoregressive, local checkpoint | `code/laya_engine.py` |
| Perception | Qwen3.6-35B-A3B + mmproj vision over an OpenAI-compatible endpoint | `code/model_tasks.py` |
| Regulator | none ? deterministic lexicon | `code/intent.py` |

The perception seat made **0 calls**: no screenshot was needed for this dataset,
and the vision pass attempted over the 11 images failed because the endpoint was
not running (connection refused). That is recorded rather than presented as a
success, and it is why `account_002`/`account_004` stay unbound.

## 3. Development-time calls (not part of the shipped run)

| Purpose | In | Out |
|---|---|---|
| connectivity probe | 19 | 2 |
| intent classification probe | 216 | 95 |
| screenshot transcription probe | 2,046 | 531 |
| **total** | **2,281** | **628** |

## 4. Cost at $0.042 / 1M input, $0 output

| Scope | Input tokens | Cost |
|---|---|---|
| shipped 518-case run (Laya, local) | 1,997,232 | **$0.00** |
| same volume priced as a hosted API | 1,997,232 | $0.084 |
| development calls | 2,281 | $0.0001 |

No API keys or credentials appear in this report, the ledger, or `code/`.
