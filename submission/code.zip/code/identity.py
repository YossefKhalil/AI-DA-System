#!/usr/bin/env python3
"""Subject resolution.

Maps the email on a deletion request to a stable ``user_id`` and to the full
set of identifiers that may still appear in older systems: current and
historical emails, phone numbers, and email hashes.

This module only resolves *who* the subject is. It never decides policy and
never decides whether a resource belongs to them.
"""

from __future__ import annotations

import csv
import re
from dataclasses import dataclass, field
from pathlib import Path

try:
    from . import config
except ImportError:  # running as a plain script
    import config

HASH_RE = re.compile(r"\b[0-9a-fA-F]{64}\b")
PHONE_RE = re.compile(r"^\+?[\d\s().\-]{7,}$")


def _rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def normalize_email(value: str) -> str:
    return value.strip().strip("<>").lower()


def normalize_phone(value: str) -> str:
    """Reduce a phone number to comparable digits."""
    return re.sub(r"\D", "", value or "")


@dataclass
class Subject:
    """Everything we know about the person behind a request."""

    user_id: str = ""
    name: str = ""
    emails: set[str] = field(default_factory=set)
    phones: set[str] = field(default_factory=set)
    hashes: set[str] = field(default_factory=set)

    @property
    def surname(self) -> str:
        """The last word of the name, which is the discriminating one."""
        parts = [part for part in re.split(r"\s+", self.name.strip()) if part]
        return parts[-1] if parts else ""

    def add_email(self, value: str) -> None:
        value = normalize_email(value)
        if "@" in value:
            self.emails.add(value)

    def add_phone(self, value: str) -> None:
        digits = normalize_phone(value)
        if len(digits) >= 7:
            self.phones.add(digits)

    def add_hash(self, value: str) -> None:
        value = (value or "").strip().lower()
        if HASH_RE.fullmatch(value):
            self.hashes.add(value)

    def add_value(self, value: str) -> None:
        """Classify one identifier-looking string and store it."""
        value = (value or "").strip()
        if not value:
            return
        if "@" in value:
            self.add_email(value)
        elif HASH_RE.fullmatch(value.lower()):
            self.add_hash(value)
        elif PHONE_RE.match(value) and len(normalize_phone(value)) >= 7:
            self.add_phone(value)

    def tokens(self) -> set[str]:
        """Literal strings that, if present in a record, name this subject."""
        out = set(self.emails) | set(self.hashes)
        if self.user_id:
            out.add(self.user_id.lower())
        return out

    def matches_tokens(self, values) -> bool:
        for value in values:
            text = str(value or "").strip().lower()
            if not text:
                continue
            if text in self.emails or text in self.hashes:
                return True
            if self.user_id and text == self.user_id.lower():
                return True
            digits = normalize_phone(text)
            if len(digits) >= 7 and digits in self.phones:
                return True
        return False


def load_subjects() -> dict[str, Subject]:
    """Build the subject directory from identities plus identity history."""
    subjects: dict[str, Subject] = {}

    for row in _rows(config.DATASET_DIR / "user_identities.csv"):
        subject = subjects.setdefault(row["user_id"], Subject(user_id=row["user_id"]))
        subject.name = (row.get("name") or "").strip()
        subject.add_email(row.get("email", ""))
        subject.add_phone(row.get("phone", ""))
        subject.add_hash(row.get("email_hash", ""))

    for row in _rows(config.DATASET_DIR / "user_audit_log.csv"):
        subject = subjects.setdefault(row["user_id"], Subject(user_id=row["user_id"]))
        # ``field_name`` says exactly what changed, so it is authoritative. The
        # regex classifier is only a fallback: it happens to agree on this
        # dataset, but a differently formatted phone or hash would be dropped
        # silently, which means an identifier we would never search for.
        field = (row.get("field_name") or "").strip().lower()
        for value in (row.get("old_value", ""), row.get("new_value", "")):
            value = (value or "").strip()
            if not value:
                continue
            if field == "email":
                subject.add_email(value)
            elif field == "email_hash":
                subject.add_hash(value)
            elif field == "phone":
                subject.add_phone(value)
            else:
                subject.add_value(value)

    return subjects


def build_email_index(subjects: dict[str, Subject]) -> dict[str, str]:
    """Map every known email, current or historical, to its user_id."""
    index: dict[str, str] = {}
    for user_id, subject in subjects.items():
        for email in subject.emails:
            index.setdefault(email, user_id)
    return index


class Directory:
    """Resolve a request email to a Subject."""

    def __init__(self) -> None:
        self.subjects = load_subjects()
        self.by_email = build_email_index(self.subjects)

    def resolve(self, email: str) -> Subject | None:
        user_id = self.by_email.get(normalize_email(email))
        if not user_id:
            return None
        return self.subjects.get(user_id)

    def all_emails(self) -> set[str]:
        return set(self.by_email)


def main() -> int:
    directory = Directory()
    print(f"subjects:  {len(directory.subjects)}")
    print(f"emails:    {len(directory.by_email)}")
    missing = 0
    for row in _rows(config.DATASET_DIR / "sample_deletion_requests.csv"):
        subject = directory.resolve(row["email"])
        if subject is None:
            missing += 1
            print(f"  unresolved: {row['case_id']} {row['email']}")
    print(f"sample requests unresolved: {missing}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
