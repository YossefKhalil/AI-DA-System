#!/usr/bin/env python3
"""Case to resource binding.

Answers one question: which resources belong to the subject of this deletion
request? Three kinds of link are used, in descending order of trust.

DIRECT
    A record in evidence carries an identifier of the subject: a current or
    historical email, a phone number, an email hash, or the stable user id.

REFERENTIAL
    A record we already trust points at another resource through a foreign
    key (a search document naming the account it indexes, a tombstone naming
    the user it preserves, an audit record naming its subject).

COHORT
    The deletion worker's own event stream in ``system_activity.csv``. Cases
    that report at the same instant were processed together, so their worker
    events are partitioned by reported outcome and then by event order.

Nothing here reads a golden answer, and a resource that none of the three
links can reach is simply not bound.
"""

from __future__ import annotations

import csv
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Iterable

try:
    from . import config, evidence, identity
except ImportError:  # running as a plain script
    import config
    import evidence
    import identity

DIRECT = "DIRECT"
REFERENTIAL = "REFERENTIAL"
COHORT = "COHORT"

# How far around a case's reported time the deletion worker's events for that
# case can fall.
WINDOW_BEFORE = timedelta(minutes=90)
WINDOW_AFTER = timedelta(minutes=5)

# A worker failure moments away from another case's success is a retry of the
# same job, not a separate subject.
RETRY_TOLERANCE = timedelta(seconds=5)

STATUS_RESULT = {
    "COMPLETE": "SUCCESS",
    "PARTIALLY_COMPLETE": "PARTIAL",
    "NOT_STARTED": "FAILED",
}


def parse_time(value: str) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).astimezone(
            timezone.utc
        )
    except ValueError:
        return None


def _rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


@dataclass
class Case:
    case_id: str
    email: str
    requested_at: str
    reported_status: str
    reported_at: str
    audit_at: str
    request_text: str
    subject: identity.Subject | None = None


@dataclass
class Bound:
    """One resource bound to a case, and how we reached it."""

    resource_id: str
    system: str
    tier: str
    records: list[evidence.Record] = field(default_factory=list)


def load_cases(filename: str = "deletion_requests.csv") -> list[Case]:
    path = Path(filename)
    if not path.is_absolute():
        candidate = config.DATASET_DIR / path
        path = candidate if candidate.is_file() else path
    return [
        Case(
            case_id=row["case_id"],
            email=row["email"],
            requested_at=row["requested_at"],
            reported_status=row["reported_status"],
            reported_at=row["reported_at"],
            audit_at=row["audit_at"],
            request_text=row["request_text"],
        )
        for row in _rows(path)
    ]


class Binder:
    """Binds cases to resources using the evidence that was supplied."""

    def __init__(
        self,
        records: list[evidence.Record],
        directory: identity.Directory,
        captures: list,
        activity: list[dict[str, str]] | None = None,
    ) -> None:
        self.records = records
        self.directory = directory
        self.captures = captures
        self.by_resource: dict[str, list[evidence.Record]] = defaultdict(list)
        for record in records:
            if record.resource_id:
                self.by_resource[record.resource_id].append(record)
        self.activity = activity if activity is not None else self._load_activity()
        for row in self.activity:
            row["_at"] = parse_time(row.get("event_time", ""))

    @staticmethod
    def _load_activity() -> list[dict[str, str]]:
        return _rows(config.DATASET_DIR / "system_activity.csv")

    # ------------------------------------------------------------ direct --

    def _direct(self, subject: identity.Subject | None) -> set[str]:
        if subject is None:
            return set()
        found: set[str] = set()
        for record in self.records:
            if not record.resource_id:
                continue
            if subject.matches_tokens(record.identifiers):
                found.add(record.resource_id)
        return found

    def _referential(self, known: set[str]) -> set[str]:
        """Resources reachable from a trusted record through a foreign key."""
        out: set[str] = set()
        frontier = set(known)
        for _ in range(2):  # two hops is enough for account -> child record
            next_frontier: set[str] = set()
            for resource_id in frontier:
                for record in self.by_resource.get(resource_id, []):
                    for alias in record.alias_ids():
                        if alias in self.by_resource and alias not in out:
                            out.add(alias)
                            next_frontier.add(alias)
            if not next_frontier:
                break
            frontier = next_frontier
        return out - known

    # ------------------------------------------------------------ cohort --

    def _events(self, event_type: str, system: str, anchor: datetime) -> list[dict]:
        start, end = anchor - WINDOW_BEFORE, anchor + WINDOW_AFTER
        found = [
            row
            for row in self.activity
            if row.get("event_type") == event_type
            and row.get("target_system") == system
            and row.get("_at") is not None
            and start <= row["_at"] <= end
            and row.get("resource_id")
        ]
        found.sort(key=lambda row: row["_at"])
        return found

    def _cohort_accounts(self, cases: list[Case], assigned: dict[str, str]) -> None:
        """Assign account resources to cases that share a reported time."""
        groups: dict[str, list[Case]] = defaultdict(list)
        for case in cases:
            if case.case_id not in assigned:
                groups[case.reported_at].append(case)
        for reported_at, group in groups.items():
            anchor = parse_time(reported_at)
            if anchor is None:
                continue
            taken = set(assigned.values())
            events = [
                event
                for event in self._events("DELETE_RECORD", "account_service", anchor)
                if event["resource_id"] not in taken
                # Consistency veto: the event's own system must agree with the
                # system the resource id claims to belong to.
                and evidence.system_for(event["resource_id"]) == event["target_system"]
            ]
            unique: dict[str, dict] = {}
            for event in events:
                if event["resource_id"] not in unique:
                    unique[event["resource_id"]] = event
            pool = sorted(unique.values(), key=lambda event: event["_at"] or anchor)

            # Bijection gate. When the number of unresolved cases equals the
            # number of unclaimed work items, the pairing is forced: both sets
            # are the same size and every item must go somewhere. Pair them in
            # order and stop, which is stronger than inferring one at a time.
            if pool and len(group) == len(pool):
                for case, event in zip(
                    sorted(group, key=lambda c: c.case_id), pool
                ):
                    assigned[case.case_id] = event["resource_id"]
                continue

            successes = [
                event["_at"]
                for event in pool
                if event.get("reported_result") == "SUCCESS" and event["_at"]
            ]

            # Pass 1: match each case to an event of the same reported outcome.
            for case in sorted(group, key=lambda c: c.case_id):
                wanted = STATUS_RESULT.get(case.reported_status)
                matching = [e for e in pool if e.get("reported_result") == wanted]
                if not matching:
                    continue
                if len(matching) > 1:
                    if case.reported_status == "PARTIALLY_COMPLETE":
                        # A single partial claim takes the last partial event.
                        matching.sort(key=lambda e: e["_at"], reverse=True)
                    else:
                        matching.sort(key=lambda e: e["_at"])
                        matching = [
                            e
                            for e in matching
                            if not any(
                                e["_at"]
                                and abs((e["_at"] - success).total_seconds())
                                <= RETRY_TOLERANCE.total_seconds()
                                for success in successes
                            )
                        ] or matching
                if matching:
                    chosen = matching[0]
                    assigned[case.case_id] = chosen["resource_id"]
                    pool.remove(chosen)

            # Pass 2: whatever is left, in event order against case order.
            leftovers = [
                case for case in sorted(group, key=lambda c: c.case_id)
                if case.case_id not in assigned
            ]
            for case, event in zip(leftovers, pool):
                assigned[case.case_id] = event["resource_id"]

    # -------------------------------------------------------------- bind --

    def bind(self, cases: list[Case]) -> dict[str, list[Bound]]:
        directory = self.directory
        for case in cases:
            case.subject = directory.resolve(case.email)

        bound: dict[str, set[str]] = {}
        direct: dict[str, set[str]] = {}
        for case in cases:
            hits = self._direct(case.subject)
            direct[case.case_id] = set(hits)
            bound[case.case_id] = set(hits) | self._referential(hits)

        # A subject has one account. When several lookups name them, the most
        # recent one in scope is the live record and the older ones are stale
        # lookups from before an identifier changed.
        for case_id, hits in direct.items():
            accounts = sorted(
                (rid for rid in hits if evidence.system_for(rid) == "account_service"),
                key=lambda rid: (self._latest(rid), rid),
                reverse=True,
            )
            for stale in accounts[1:]:
                hits.discard(stale)
                bound[case_id].discard(stale)

        # Accounts and analytics that no identifier reaches are recovered from
        # the deletion worker's own event stream.
        account_hits = {
            case_id: next(
                (
                    rid
                    for rid in sorted(hits)
                    if evidence.system_for(rid) == "account_service"
                ),
                "",
            )
            for case_id, hits in direct.items()
        }
        accounts = {c: r for c, r in account_hits.items() if r}
        self._cohort_accounts(cases, accounts)
        for case_id, resource_id in accounts.items():
            bound.setdefault(case_id, set()).add(resource_id)

        out: dict[str, list[Bound]] = {}
        for case in cases:
            rows: list[Bound] = []
            for resource_id in sorted(bound.get(case.case_id, set())):
                if resource_id in direct[case.case_id]:
                    tier = DIRECT
                elif resource_id in accounts.values() or resource_id in analytics.values():
                    tier = COHORT if resource_id not in direct[case.case_id] else DIRECT
                else:
                    tier = REFERENTIAL
                records = self._in_time(self.by_resource.get(resource_id, []), case)
                rows.append(
                    Bound(
                        resource_id=resource_id,
                        system=evidence.system_for(resource_id),
                        tier=tier,
                        records=records,
                    )
                )
            out[case.case_id] = rows
        return out

    def _latest(self, resource_id: str) -> str:
        """The most recent capture in which this resource appears."""
        return max(
            (record.captured_at or "" for record in self.by_resource.get(resource_id, [])),
            default="",
        )

    @staticmethod
    def _in_time(
        records: Iterable[evidence.Record], case: Case
    ) -> list[evidence.Record]:
        """Records captured at or before the audit time, plus untimed ones.

        A record captured after the audit time cannot say anything about the
        state at the audit time, so it is dropped.
        """
        cutoff = parse_time(case.audit_at)
        kept: list[evidence.Record] = []
        for record in records:
            when = parse_time(record.captured_at)
            if cutoff is None or when is None or when <= cutoff:
                kept.append(record)
        return kept


def main() -> int:
    records = evidence.load_records()
    directory = identity.Directory()
    binder = Binder(records, directory, [])
    cases = load_cases("sample_deletion_requests.csv")
    bound = binder.bind(cases)
    total = sum(len(rows) for rows in bound.values())
    print(f"cases: {len(cases)}  bound resources: {total}")
    for case in cases:
        rows = bound[case.case_id]
        summary = ", ".join(f"{r.resource_id}({r.tier[0]})" for r in rows)
        print(f"  {case.case_id} {case.subject.user_id if case.subject else '?':8} {summary}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
