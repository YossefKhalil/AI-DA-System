#!/usr/bin/env python3
"""Compare several prediction files, and score them against a golden when one exists.

Two different questions, so two different tables:

  with a golden   accuracy, exactly as `code/score.py` measures it
  without one     no published answer exists, so the honest comparison is
                  structural validity, the status distribution, and how much
                  the competitors actually disagree with each other

Run:
    python -X utf8 code/compare.py --golden dataset/sample_output.csv A.csv B.csv C.csv
    python -X utf8 code/compare.py A.csv B.csv C.csv
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

FIELDS = ("phase", "system_id", "resource_id", "operation", "state", "evidence_id")
ALLOWED_OPERATIONS = {
    "REPORT_REMAINING_RECORD",
    "REPORT_EXPOSED_PII",
    "REPORT_ACTIVE_DATA_FLOW",
    "REPORT_RESTORE_RISK",
    "DISABLE_DATA_FLOW",
    "BLOCK_RESTORE",
    "DELETE_RECORD",
    "REDACT_RECORD",
    "ANONYMIZE_RECORD",
    "VERIFY_RECORD_ABSENT",
    "VERIFY_RECORD_PRESENT",
    "VERIFY_RECORD_REDACTED",
    "VERIFY_RECORD_ANONYMIZED",
    "VERIFY_DATA_FLOW_DISABLED",
    "VERIFY_RESTORE_BLOCKED",
}
PHASE_ORDER = {"FINDING": 0, "REMEDIATION": 1, "VERIFICATION": 2}


def load(path: Path) -> dict[str, list[dict]]:
    out: dict[str, list[dict]] = {}
    with path.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            steps = json.loads(row["steps_json"]) if row["steps_json"].strip() else []
            out[row["case_id"]] = steps
    return out


def statuses(path: Path) -> dict[str, str]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return {row["case_id"]: row["deletion_status"] for row in csv.DictReader(handle)}


def structure(steps_by_case: dict[str, list[dict]]) -> dict:
    violations = 0
    total_steps = 0
    operations: set[str] = set()
    for steps in steps_by_case.values():
        total_steps += len(steps)
        for index, step in enumerate(steps, start=1):
            if set(step) != set(FIELDS) | {"step_no"}:
                violations += 1
            if step.get("step_no") != index:
                violations += 1
            if step.get("operation") not in ALLOWED_OPERATIONS:
                violations += 1
            operations.add(step.get("operation", ""))
    return {
        "cases": len(steps_by_case),
        "steps": total_steps,
        "violations": violations,
        "operations": len(operations),
        "phases_ordered": sum(
            1
            for steps in steps_by_case.values()
            if all(
                PHASE_ORDER[steps[i]["phase"]] <= PHASE_ORDER[steps[i + 1]["phase"]]
                for i in range(len(steps) - 1)
            )
        ),
    }


def key(steps: list[dict]) -> list[tuple]:
    return [tuple(step.get(field) for field in FIELDS) for step in steps]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("files", nargs="+")
    parser.add_argument("--golden", default="")
    parser.add_argument("--labels", default="")
    args = parser.parse_args(argv)

    paths = [Path(name) for name in args.files]
    labels = args.labels.split(",") if args.labels else [path.stem for path in paths]
    loaded = {label: load(path) for label, path in zip(labels, paths)}
    status_by = {label: statuses(path) for label, path in zip(labels, paths)}

    print("## Structure\n")
    print("| competitor | cases | steps | format violations | distinct operations | phase-ordered rows |")
    print("|---|---|---|---|---|---|")
    for label in labels:
        data = structure(loaded[label])
        print(
            f"| {label} | {data['cases']} | {data['steps']} | {data['violations']} | "
            f"{data['operations']} | {data['phases_ordered']} |"
        )

    print("\n## Deletion status distribution\n")
    print("| competitor | COMPLETE | INCOMPLETE | NOT_APPLICABLE |")
    print("|---|---|---|---|")
    for label in labels:
        counts = {"COMPLETE": 0, "INCOMPLETE": 0, "NOT_APPLICABLE": 0}
        for status in status_by[label].values():
            counts[status] = counts.get(status, 0) + 1
        print(
            f"| {label} | {counts['COMPLETE']} | {counts['INCOMPLETE']} | "
            f"{counts['NOT_APPLICABLE']} |"
        )

    if not args.golden:
        print("\n## Agreement between competitors (no golden published for this set)\n")
        print("| pair | identical rows | same status | different status | identical steps |")
        print("|---|---|---|---|---|")
        for i, left in enumerate(labels):
            for right in labels[i + 1 :]:
                rows = len(loaded[left])
                same_status = sum(
                    1
                    for case_id in loaded[left]
                    if status_by[left].get(case_id) == status_by[right].get(case_id)
                )
                same_steps = sum(
                    1
                    for case_id in loaded[left]
                    if key(loaded[left][case_id]) == key(loaded[right].get(case_id, []))
                )
                identical = sum(
                    1
                    for case_id in loaded[left]
                    if status_by[left].get(case_id) == status_by[right].get(case_id)
                    and key(loaded[left][case_id]) == key(loaded[right].get(case_id, []))
                )
                print(
                    f"| {left} vs {right} | {identical}/{rows} | {same_status}/{rows} | "
                    f"{rows - same_status}/{rows} | {same_steps}/{rows} |"
                )
        return 0

    golden = load(Path(args.golden))
    golden_status = statuses(Path(args.golden))
    print(f"\n## Accuracy against `{args.golden}`\n")
    print("| competitor | status accuracy | exact rows | step match | field accuracy | content recall | invented steps |")
    print("|---|---|---|---|---|---|---|")
    for label in labels:
        total = len(golden)
        status_ok = exact = field_ok = field_total = 0
        step_ok = step_total = 0
        recall_hit = recall_total = invented = 0
        for case_id, gold_steps in golden.items():
            steps = loaded[label].get(case_id, [])
            if status_by[label].get(case_id) == golden_status[case_id]:
                status_ok += 1
            if status_by[label].get(case_id) == golden_status[case_id] and key(steps) == key(gold_steps):
                exact += 1
            for index in range(max(len(gold_steps), len(steps))):
                step_total += 1
                aligned = index < len(gold_steps) and index < len(steps)
                matched = aligned
                for field in FIELDS:
                    field_total += 1
                    if aligned and gold_steps[index].get(field) == steps[index].get(field):
                        field_ok += 1
                    else:
                        matched = False
                if matched:
                    step_ok += 1
            pool = key(steps)
            for gold_key in key(gold_steps):
                recall_total += 1
                if gold_key in pool:
                    pool.remove(gold_key)
                    recall_hit += 1
            invented += len(pool)
        print(
            f"| {label} | {status_ok}/{total} = {status_ok / total:.2%} | {exact}/{total} | "
            f"{step_ok}/{step_total} = {step_ok / step_total:.2%} | "
            f"{field_ok}/{field_total} = {field_ok / field_total:.2%} | "
            f"{recall_hit}/{recall_total} = {recall_hit / recall_total:.2%} | {invented} |"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
