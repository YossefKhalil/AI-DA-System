#!/usr/bin/env python3
"""Turn observations into the graded step list.

A case is ``COMPLETE`` when every in-scope resource already has the state
policy requires at ``audit_at``, and ``INCOMPLETE`` when any of them does not.
Findings cite the evidence that shows the violation; remediation and the
post-remediation verification steps are future work and carry no evidence id.
"""

from __future__ import annotations

try:
    from . import policy
except ImportError:  # running as a plain script
    import policy

PHASE_ORDER = {"FINDING": 0, "REMEDIATION": 1, "VERIFICATION": 2}

OP_ORDER = {
    # findings
    "REPORT_REMAINING_RECORD": 0,
    "REPORT_EXPOSED_PII": 1,
    "REPORT_ACTIVE_DATA_FLOW": 2,
    "REPORT_RESTORE_RISK": 3,
    # remediation: stop the copying and restoring before touching records
    "DISABLE_DATA_FLOW": 0,
    "BLOCK_RESTORE": 1,
    "DELETE_RECORD": 2,
    "REDACT_RECORD": 3,
    "ANONYMIZE_RECORD": 4,
    # verification
    "VERIFY_RECORD_ABSENT": 0,
    "VERIFY_RECORD_PRESENT": 1,
    "VERIFY_RECORD_REDACTED": 2,
    "VERIFY_RECORD_ANONYMIZED": 3,
    "VERIFY_DATA_FLOW_DISABLED": 4,
    "VERIFY_RESTORE_BLOCKED": 5,
}


def _step(step_no: int, phase: str, row: tuple) -> dict:
    _, operation, system_id, resource_id, evidence_id = row
    return {
        "step_no": step_no,
        "phase": phase,
        "system_id": system_id,
        "resource_id": resource_id,
        "operation": operation,
        "state": policy.state_for_operation(operation),
        "evidence_id": evidence_id,
    }


def plan(observations: list) -> tuple[str, list[dict]]:
    """Return ``(deletion_status, steps)`` for one case."""
    rows: list[tuple] = []
    violations = 0

    for obs in observations:
        if obs.observed == obs.desired:
            continue
        operation = policy.FINDING_FOR.get(obs.desired)
        if operation is None:
            # A retained record that is missing has no finding operation in the
            # contract, so there is nothing we are allowed to report for it.
            continue
        violations += 1
        rows.append(("FINDING", operation, obs.system, obs.resource_id, obs.evidence_id))
        remedy = policy.REMEDY_FOR.get(obs.desired)
        if remedy:
            rows.append(("REMEDIATION", remedy, obs.system, obs.resource_id, ""))

    status = "COMPLETE" if violations == 0 else "INCOMPLETE"

    # Every in-scope resource is verified, not only the ones we had to fix.
    for obs in observations:
        operation = policy.VERIFY_FOR[obs.desired]
        evidence = obs.evidence_id if status == "COMPLETE" else ""
        rows.append(("VERIFICATION", operation, obs.system, obs.resource_id, evidence))

    rows.sort(key=lambda row: (PHASE_ORDER[row[0]], OP_ORDER[row[1]], row[2], row[3]))
    return status, [_step(i, row[0], row) for i, row in enumerate(rows, start=1)]
