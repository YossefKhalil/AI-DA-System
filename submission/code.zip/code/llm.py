#!/usr/bin/env python3
"""OpenAI-compatible chat transport.

The only place in the project that performs network I/O. It knows about
messages, JSON schemas, caching and token accounting - and nothing about
the audit domain. Prompts and schemas live in model_tasks.py.

Any OpenAI-compatible server works. The default target is a local
llama.cpp server launched as:

    llama-server -m <model.gguf> -mm <mmproj.gguf> --port 8080

Because that server may reject optional fields (response_format,
chat_template_kwargs) depending on build, each request is attempted with
the full body first and then with progressively fewer extras.

CLI:
    python code/llm.py models
    python code/llm.py ping
"""

from __future__ import annotations

import base64
import hashlib
import json
import re
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

try:  # package import and direct-script import both work
    from . import config
except ImportError:  # pragma: no cover
    import config  # type: ignore


# ------------------------------------------------------------- accounting --

@dataclass
class Usage:
    """Token and call accounting for the current process."""

    calls: int = 0
    cached_calls: int = 0
    failed_calls: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    wall_seconds: float = 0.0
    by_task: dict[str, int] = field(default_factory=dict)

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens

    def record_call(self, task: str, prompt: int, completion: int, seconds: float) -> None:
        self.calls += 1
        self.prompt_tokens += prompt
        self.completion_tokens += completion
        self.wall_seconds += seconds
        self.by_task[task] = self.by_task.get(task, 0) + 1

    def record_cache_hit(self, prompt: int, completion: int) -> None:
        self.cached_calls += 1
        self.prompt_tokens += prompt
        self.completion_tokens += completion

    def as_dict(self) -> dict[str, Any]:
        return {
            "calls": self.calls,
            "cached_calls": self.cached_calls,
            "failed_calls": self.failed_calls,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_tokens": self.total_tokens,
            "wall_seconds": round(self.wall_seconds, 3),
            "by_task": dict(sorted(self.by_task.items())),
        }


USAGE = Usage()


def flush_ledger(model: str = "") -> None:
    """Write the running ledger so a long run can be inspected mid-flight."""
    config.EVALUATION_DIR.mkdir(parents=True, exist_ok=True)
    (config.EVALUATION_DIR / "usage_ledger.json").write_text(
        json.dumps(
            {
                "base_url": config.BASE_URL,
                "model": model or config.MODEL or "(auto-discovered)",
                "usage": USAGE.as_dict(),
            },
            indent=2,
        ),
        encoding="utf-8",
    )


# ------------------------------------------------------------------ cache --

def _cache_file(key: str) -> Path:
    return config.CACHE_DIR / "llm" / key[:2] / f"{key[2:]}.json"


def _cache_read(key: str) -> dict | None:
    path = _cache_file(key)
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _cache_write(key: str, value: dict) -> None:
    path = _cache_file(key)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")


# ------------------------------------------------------------------- http --

def _post(path: str, body: dict, retries: int) -> dict:
    data = json.dumps(body).encode("utf-8")
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {config.API_KEY}"}
    error: Exception | None = None
    for attempt in range(retries + 1):
        request = urllib.request.Request(
            f"{config.BASE_URL}{path}", data=data, headers=headers, method="POST"
        )
        try:
            with urllib.request.urlopen(request, timeout=config.TIMEOUT) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", "ignore")[:400]
            error = RuntimeError(f"HTTP {exc.code} from {path}: {detail}")
            if exc.code in (400, 404, 422):  # request shape is wrong: no retry
                raise error
        except Exception as exc:  # noqa: BLE001 - connection errors, resets, timeouts
            error = exc
        if attempt < retries:
            time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"POST {path} failed: {error}")


def list_models() -> list[str]:
    request = urllib.request.Request(
        f"{config.BASE_URL}/models",
        headers={"Authorization": f"Bearer {config.API_KEY}"},
    )
    with urllib.request.urlopen(request, timeout=30) as response:
        payload = json.loads(response.read().decode("utf-8"))
    return [entry.get("id", "") for entry in payload.get("data", []) if entry.get("id")]


_DISCOVERED_MODEL: str | None = None


def resolve_model() -> str:
    """Explicit env model, else the first model the server advertises."""
    global _DISCOVERED_MODEL
    if config.MODEL:
        return config.MODEL
    if _DISCOVERED_MODEL is None:
        found = list_models()
        if not found:
            raise RuntimeError(f"no models advertised by {config.BASE_URL}/models")
        _DISCOVERED_MODEL = found[0]
    return _DISCOVERED_MODEL


# ------------------------------------------------------------------ parts --

def image_part(path: Path) -> dict:
    """Encode a local image file as an OpenAI image_url content part."""
    path = Path(path)
    suffix = path.suffix.lower().lstrip(".")
    mime = {"jpg": "jpeg", "jpeg": "jpeg", "webp": "webp"}.get(suffix, "png")
    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return {"type": "image_url", "image_url": {"url": f"data:image/{mime};base64,{encoded}"}}


_FENCE = re.compile(r"^```(?:json)?\s*(.*?)\s*```$", re.DOTALL)


def parse_json(text: str) -> Any:
    """Recover a JSON value from a model reply, tolerating prose or fences."""
    stripped = text.strip()
    fenced = _FENCE.match(stripped)
    if fenced:
        stripped = fenced.group(1).strip()
    try:
        return json.loads(stripped)
    except ValueError:
        pass
    for opener, closer in (("{", "}"), ("[", "]")):
        start, end = stripped.find(opener), stripped.rfind(closer)
        if 0 <= start < end:
            try:
                return json.loads(stripped[start : end + 1])
            except ValueError:
                continue
    raise ValueError(f"no JSON in reply: {text[:200]!r}")


# ------------------------------------------------------------------- chat --

@dataclass
class Reply:
    text: str
    json: Any | None
    usage: dict
    cached: bool


def chat(
    messages: list[dict],
    *,
    task: str = "generic",
    schema: dict | None = None,
    max_tokens: int = 1024,
    temperature: float = 0.0,
    thinking: bool = False,
    use_cache: bool = True,
    retries: int = 2,
) -> Reply:
    """One deterministic, cached, accounted chat completion.

    Optional fields are dropped one at a time if the server rejects them,
    so the same code works against llama.cpp, vLLM or a hosted API.
    """
    base: dict[str, Any] = {
        "model": resolve_model(),
        "messages": messages,
        "temperature": temperature,
        "top_p": 1.0,
        "seed": 0,
        "max_tokens": max_tokens,
    }

    extras: list[dict[str, Any]] = []
    if not thinking:
        extras.append({"chat_template_kwargs": {"enable_thinking": False}})
    if schema is not None:
        extras.append(
            {
                "response_format": {
                    "type": "json_schema",
                    "json_schema": {"name": "result", "strict": True, "schema": schema},
                }
            }
        )

    full_body = {**base, **{k: v for extra in extras for k, v in extra.items()}}
    cache_key = hashlib.sha256(
        json.dumps(full_body, sort_keys=True, ensure_ascii=False).encode("utf-8")
    ).hexdigest()

    if use_cache:
        hit = _cache_read(cache_key)
        if hit is not None:
            stored = hit.get("ledger") or {}
            USAGE.record_cache_hit(
                int(stored.get("prompt_tokens", 0)), int(stored.get("completion_tokens", 0))
            )
            return Reply(hit["text"], hit.get("json"), hit.get("usage") or {}, cached=True)

    started = time.monotonic()
    payload = None
    last_error: Exception | None = None
    for skip in range(len(extras) + 1):
        body = {**base, **{k: v for extra in extras[: len(extras) - skip] for k, v in extra.items()}}
        try:
            payload = _post("/chat/completions", body, retries)
            break
        except RuntimeError as exc:
            last_error = exc
    if payload is None:
        USAGE.failed_calls += 1
        flush_ledger()
        raise last_error if last_error else RuntimeError("chat completion failed")
    elapsed = time.monotonic() - started

    text = (payload.get("choices") or [{}])[0].get("message", {}).get("content") or ""
    usage = payload.get("usage") or {}
    prompt_tokens = int(usage.get("prompt_tokens", 0))
    completion_tokens = int(usage.get("completion_tokens", 0))

    USAGE.record_call(task, prompt_tokens, completion_tokens, elapsed)
    flush_ledger(payload.get("model", ""))

    parsed = None
    if schema is not None or text.lstrip()[:1] in {"{", "[", "`"}:
        try:
            parsed = parse_json(text)
        except ValueError:
            parsed = None

    if use_cache:
        _cache_write(
            cache_key,
            {
                "text": text,
                "json": parsed,
                "usage": usage,
                "ledger": {
                    "prompt_tokens": prompt_tokens,
                    "completion_tokens": completion_tokens,
                },
            },
        )

    return Reply(text=text, json=parsed, usage=usage, cached=False)


# -------------------------------------------------------------------- cli --

def main(argv: Iterable[str]) -> int:
    argv = list(argv)
    command = argv[0] if argv else "ping"

    if command == "models":
        for model_id in list_models():
            print(model_id)
        return 0

    if command == "ping":
        reply = chat([{"role": "user", "content": "Reply with the single word: ready"}], max_tokens=16)
        print(reply.text.strip())
        print(f"cached={reply.cached} usage={reply.usage}")
        return 0

    print(f"unknown command: {command}", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
