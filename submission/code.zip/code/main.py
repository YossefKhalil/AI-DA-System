#!/usr/bin/env python3
"""Ghost Data Still Exists -- deletion-audit agent.

Reads ``dataset/deletion_requests.csv``, decides for every case whether the
request authorises deletion, reconstructs the state of each in-scope resource
at the case's ``audit_at``, applies the deletion policy, and writes the graded
``output.csv`` at the repository root.

Run:
    python -X utf8 code/main.py
    python -X utf8 code/main.py --requests sample_deletion_requests.csv --output sample_prediction.csv
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import re
import subprocess
import sys
from pathlib import Path

try:
    from . import (
        config,
        evidence,
        identity,
        intent,
        llm,
        observe,
        pack,
        plan,
        resolve,
    )
except ImportError:  # running as a plain script
    import config
    import evidence
    import identity
    import intent
    import llm
    import observe
    import pack
    import plan
    import resolve

NOT_APPLICABLE = "NOT_APPLICABLE"


def _sort_key(case_id: str) -> tuple[int, str]:
    tail = case_id.rsplit("_", 1)[-1]
    return (int(tail), case_id) if tail.isdigit() else (1 << 30, case_id)


def _audit(case, bound: list, captures: list) -> tuple[str, list[dict]]:
    """Observe every in-scope resource, then let the planner build the steps."""
    observations = []
    seen: set[tuple[str, str]] = set()
    for item in bound:
        key = (item.system, item.resource_id)
        if key in seen:
            continue
        seen.add(key)
        observations.append(
            observe.observed_state(
                item.resource_id,
                item.system,
                item.records,
                case.subject,
                captures,
                case.audit_at,
            )
        )
    return plan.plan(observations)


CANDIDATE_CAP = 10


def _in_window(record, case) -> bool:
    when = observe.parse_time(record.captured_at)
    if when is None:
        return True
    start = observe.parse_time(case.requested_at)
    end = observe.parse_time(case.audit_at)
    return (start is None or when >= start) and (end is None or when <= end)


def _summary(records: list) -> list[tuple[str, str]]:
    fields: dict[str, str] = {}
    for record in records:
        for key, value in record.attributes.items():
            if key in {"resource_id", "observed_at", "captured_at", "updated_at"}:
                continue
            if value not in ("", None) and key not in fields:
                fields[key] = str(value)[:60]
    return list(fields.items())[:8]


def _candidates(case, bound: list, binder, claimed: set[str]) -> dict[str, list[dict]]:
    """Records the case might own, in systems it does not already cover.

    Candidates come from the files that already proved this case's other
    records, which keeps the set small; a case with nothing bound yet falls
    back to anything captured inside its own window.
    """
    files = {record.file_id for item in bound for record in item.records}
    covered = {item.system for item in bound}
    out: dict[str, list[dict]] = {}
    for resource_id, records in binder.by_resource.items():
        if resource_id in claimed:
            continue
        system = evidence.system_for(resource_id)
        if system in covered or system == "unknown":
            continue
        timed = [record for record in records if _in_window(record, case)]
        if not timed:
            continue
        if files and config.CANDIDATE_POOL == "file" and not (
            files & {record.file_id for record in timed}
        ):
            continue
        bucket = out.setdefault(system, [])
        if len(bucket) >= config.CANDIDATE_CAP:
            continue
        fields = _summary(timed)
        captured = max((r.captured_at for r in timed), default="")
        rendered = ", ".join(f"{k}={v}" for k, v in fields) or "no fields"
        bucket.append(
            {
                "resource_id": resource_id,
                "system": system,
                "captured_at": captured,
                "fields": fields,
                "text": f"{resource_id} in {system}, captured {captured or 'unknown'}: {rendered}",
            }
        )
    return out


def _subject_text(case) -> str:
    """The case dossier handed to the decision model."""
    lines = [f"Customer request email: {case.email}"]
    subject = case.subject
    if subject is not None:
        lines.append(f"Internal reference: {subject.user_id}")
        if subject.emails:
            lines.append("Emails: " + ", ".join(sorted(subject.emails)))
        if subject.phones:
            lines.append("Phones: " + ", ".join(sorted(subject.phones)))
        if subject.hashes:
            lines.append("Email hashes: " + ", ".join(sorted(subject.hashes)))
    lines.append(f"Request submitted {case.requested_at}, audit cutoff {case.audit_at}")
    return "\n".join(lines)


_RESOURCE_IN_TEXT = re.compile(
    r"\b((?:%s)_[0-9]+)\b"
    % "|".join(sorted(evidence.PREFIX_SYSTEM, key=len, reverse=True))
)
_CORPUS_CHUNKS: list[tuple[str, str, str]] | None = None


def _corpus_chunks() -> list[tuple[str, str, str]]:
    """Every evidence file cut into ordered pieces, built once and reused.

    (file_id, captured_at, text). Reading and chunking 94 files per case would
    dominate the run, so this is cached for the process.
    """
    global _CORPUS_CHUNKS
    if _CORPUS_CHUNKS is None:
        chunks: list[tuple[str, str, str]] = []
        for row in evidence.manifest():
            path = config.DATASET_DIR / row["file_path"]
            if not path.is_file():
                continue
            if path.suffix.lower() not in {".log", ".txt", ".json", ".sql", ".csv", ".md"}:
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for piece in pack.chunk(text, config.EVIDENCE_MATCH_CHUNK_TOKENS):
                chunks.append((row["file_id"], row.get("captured_at", ""), piece))
        _CORPUS_CHUNKS = chunks
    return _CORPUS_CHUNKS


def _identifier_text(case) -> str:
    """The case's identifiers, as the criterion the evidence is matched against.

    Every form the person's identity takes: the request address, the current and
    historical emails, phones and hashes, the stable internal reference and the
    name. This is what the passages are compared against, so it is the whole
    set rather than a single token.
    """
    subject = case.subject
    parts = [f"request email {case.email}"]
    if subject is not None:
        if subject.name:
            parts.append(f"name {subject.name}")
        if subject.emails:
            parts.append("emails " + ", ".join(sorted(subject.emails)))
        if subject.phones:
            parts.append("phones " + ", ".join(sorted(subject.phones)))
        if subject.hashes:
            parts.append("email hashes " + ", ".join(sorted(subject.hashes)))
        if subject.user_id:
            parts.append(f"internal reference {subject.user_id}")
    return "; ".join(parts)


def _match_candidates(case, bound: list) -> list[tuple[str, str]]:
    """Passages eligible to be matched: (file_id, text).

    Two principled filters only. A file already supplying this case's records is
    skipped because it is accounted for, and a passage captured after the audit
    cutoff is skipped because it cannot describe the state at that time. Nothing
    is filtered on whether an identifier has already been seen, because the
    point of the pass is to reach evidence the identifier matcher could not.
    """
    spoken_for = {record.file_id for item in bound for record in item.records}
    cutoff = observe.parse_time(case.audit_at)
    out: list[tuple[str, str]] = []
    for file_id, captured_at, text in _corpus_chunks():
        if file_id in spoken_for:
            continue
        when = observe.parse_time(captured_at)
        if cutoff is not None and when is not None and when > cutoff:
            continue
        out.append((file_id, text))
        if config.EVIDENCE_MATCH_MAX_CHUNKS and len(out) >= config.EVIDENCE_MATCH_MAX_CHUNKS:
            break
    return out


def _evidence_match(case, bound: list, additions: list, binder, claimed: set[str]) -> None:
    """Match every eligible passage against the case's identifiers.

    The passage is the state and the identifiers are the question, so the model
    answers MATCH or NO_MATCH for each passage in one batched pass. A match is
    not trusted on its own: code extracts the resource ids the passage names and
    keeps only those that exist in the parsed index, fall inside the case window,
    and belong to a system the case does not already cover.
    """
    engine = _laya()
    if engine is None or not config.EVIDENCE_MATCH:
        return
    pairs = _match_candidates(case, bound)
    if not pairs:
        return
    results = engine.match_chunks(_identifier_text(case), [text for _, text in pairs])
    covered = {item.system for item in bound + additions}
    have = {item.resource_id for item in bound + additions}
    for (file_id, text), (matched, _) in zip(pairs, results):
        if not matched:
            continue
        engine.STATS["match_hits"] = engine.STATS.get("match_hits", 0) + 1
        for resource_id in _RESOURCE_IN_TEXT.findall(text):
            if resource_id in claimed or resource_id in have:
                continue
            system = evidence.system_for(resource_id)
            if system in covered or system == "unknown":
                continue
            records = [
                record
                for record in binder.by_resource.get(resource_id, [])
                if _in_window(record, case)
            ]
            if not records:
                continue
            additions.append(resolve.Bound(resource_id, system, "MODEL-MATCH", records))
            claimed.add(resource_id)
            have.add(resource_id)
            engine.STATS["match_bound"] = engine.STATS.get("match_bound", 0) + 1



def _laya():
    """The decision model when its checkpoint is present, otherwise None."""
    try:
        from . import laya_engine
    except ImportError:
        import laya_engine
    return laya_engine if laya_engine.available() else None


def _decide_intent(case, engine) -> str:
    """Decide whether the request authorises deletion.

    The decision model answers; the deterministic lexicon acts as a guard when
    ``LEXICON_GUARD`` is on, because reading a deletion request as "not a
    deletion" empties the whole case. With the guard off the model's answer
    stands unconditionally. The lexicon is also the fallback when no checkpoint
    is available.
    """
    lexicon = intent.classify(case.request_text)
    if engine is None:
        return lexicon
    label, _ = engine.classify_intent(case.request_text)
    if not label:
        engine.STATS["intent_abstained"] += 1
        return lexicon
    model = intent.NON_DELETION if label == "NON_DELETION" else intent.DELETION
    if config.LEXICON_GUARD and lexicon != intent.UNKNOWN and lexicon != model:
        engine.STATS["intent_disagreements"] = engine.STATS.get("intent_disagreements", 0) + 1
        return lexicon
    return model


def _apply_model(case, bound: list, binder, claimed: set[str], captures: list):
    """The decision model chooses bindings and required states for one case."""
    additions: list = []
    candidates = _candidates(case, bound, binder, claimed)
    flat = [item for items in candidates.values() for item in items]
    engine = _laya()
    if flat and engine is not None:
        _, scores = engine.bind(_subject_text(case), flat)
        by_system: dict[str, list[tuple[float, str]]] = {}
        for item in flat:
            by_system.setdefault(item["system"], []).append(
                (scores.get(item["resource_id"], 0.0), item["resource_id"])
            )
        accepted = []
        for system, ranked in by_system.items():
            ranked.sort(reverse=True)
            best = ranked[0][0]
            runner_up = ranked[1][0] if len(ranked) > 1 else 0.0
            if best >= config.LAYA_BIND_THRESHOLD and best - runner_up >= config.LAYA_BIND_MARGIN:
                accepted.append((best, ranked[0][1]))
        accepted.sort(reverse=True)
        accepted = [resource_id for _, resource_id in accepted[: config.BIND_MAX_PER_CASE]]
        for resource_id in accepted:
            system = evidence.system_for(resource_id)
            records = [r for r in binder.by_resource.get(resource_id, []) if _in_window(r, case)]
            if not records or resource_id in claimed:
                continue
            additions.append(resolve.Bound(resource_id, system, "MODEL", records))
            claimed.add(resource_id)
    _evidence_match(case, bound, additions, binder, claimed)
    observations = []
    seen = set()
    for item in bound + additions:
        key = (item.system, item.resource_id)
        if key in seen:
            continue
        seen.add(key)
        observations.append(
            observe.observed_state(
                item.resource_id, item.system, item.records, case.subject, captures, case.audit_at
            )
        )
    verdict = ""
    if engine is not None and observations:
        rows = [
            {
                "resource_id": obs.resource_id,
                "system": obs.system,
                "category": obs.category,
                "observed": obs.observed,
                "desired": obs.desired,
            }
            for obs in observations
        ]
        decisions, verdict, _ = engine.judge(rows)
        for obs in observations:
            chosen = decisions.get(obs.resource_id)
            if not chosen:
                continue
            # A decision may raise a violation, never cancel an observed one:
            # the parser's reading of the evidence is a hard floor.
            if obs.observed != obs.desired and chosen == obs.observed:
                engine.STATS["cancels_blocked"] = engine.STATS.get("cancels_blocked", 0) + 1
                continue
            obs.desired = chosen
    status, steps = plan.plan(observations)
    if engine is not None:
        engine.STATS["added"] += len(additions)
        if verdict:
            engine.STATS["agree" if verdict == status else "disagree"] += 1
    return status, steps


def audit_cases(cases: list, records: list, captures: list, use_model: bool = True):
    """Yield ``(case_id, deletion_status, steps)`` for every case."""
    directory = identity.Directory()
    binder = resolve.Binder(records, directory, captures)
    bound_by_case = binder.bind(cases)

    claimed: set[str] = set()
    if use_model:
        for items in bound_by_case.values():
            for item in items:
                claimed.add(item.resource_id)

    for case in cases:
        label = _decide_intent(case, _laya() if use_model else None)
        if label == intent.NON_DELETION:
            yield case.case_id, NOT_APPLICABLE, []
            continue
        bound = bound_by_case.get(case.case_id, [])
        if use_model:
            status, steps = _apply_model(case, bound, binder, claimed, captures)
        else:
            status, steps = _audit(case, bound, captures)
        yield case.case_id, status, steps


def write_rows(rows: list[tuple[str, str, list[dict]],], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["case_id", "deletion_status", "steps_json"])
        for case_id, status, steps in sorted(rows, key=lambda row: _sort_key(row[0])):
            writer.writerow(
                [case_id, status, json.dumps(steps, ensure_ascii=False, separators=(",", ":"))]
            )


def _upgrade_to_laya_env(argv: list[str]) -> int | None:
    """Re-run inside the Laya environment when one has been set up.

    Returns ``None`` when there was nothing to hand over to, otherwise the
    child's exit status. The caller must propagate that status rather than
    treating a failure as "no model available": silently re-running
    deterministically would overwrite a good AI result with a worse one.
    """
    if os.environ.get("GHOST_LAYA_ENV") == "1":
        return None
    try:
        import laya  # noqa: F401
        return None
    except Exception:  # noqa: BLE001 - not in the Laya environment yet
        pass
    python = config.LAYA_ENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if not python.is_file():
        return None
    environment = dict(os.environ)
    environment["GHOST_LAYA_ENV"] = "1"
    environment["PYTHONPATH"] = str(config.ROOT / "code")
    completed = subprocess.run(
        [str(python), str(Path(__file__).resolve()), *argv],
        env=environment,
    )
    return completed.returncode


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--requests", default="deletion_requests.csv")
    parser.add_argument("--output", default="")
    parser.add_argument("--no-model", action="store_true", help="disable the decision model entirely (deterministic path)")
    parser.add_argument(
        "--laya",
        action="store_true",
        help="accepted for compatibility; the decision model is on by default",
    )
    args = parser.parse_args(argv)

    # The decision model is the default seat, not an opt-in. If an environment
    # for it exists, hand the process over to that environment; if not, say so
    # and continue deterministically rather than failing.
    if not args.no_model:
        handover = _upgrade_to_laya_env(list(argv if argv is not None else sys.argv[1:]))
        if handover is not None:
            return handover
    if not args.no_model and _laya() is None:
        print(
            "decision model unavailable (no Laya install or no checkpoint at "
            f"{config.LAYA_MODELS['multilingual']}); continuing deterministically. "
            "Run `python code/setup_laya.py` once to enable it.",
            file=sys.stderr,
        )
    output = Path(args.output) if args.output else config.OUTPUT_CSV

    records = evidence.load_records()
    observe.set_file_weights(records)
    captures = observe.load_captures()
    cases = resolve.load_cases(args.requests)

    rows = list(audit_cases(cases, records, captures, use_model=not args.no_model))
    write_rows(rows, output)

    counts: dict[str, int] = {}
    steps = 0
    for _, status, case_steps in rows:
        counts[status] = counts.get(status, 0) + 1
        steps += len(case_steps)
    print(f"requests: {len(rows)}  steps: {steps}")
    for status in sorted(counts):
        print(f"  {status}: {counts[status]}")
    print(f"wrote {output}")
    engine = _laya()
    if engine is not None:
        stats = engine.STATS
        print(
            "decision model (Laya): "
            f"input_tokens={stats['input_tokens']} "
            f"output_tokens={stats['output_tokens']} "
            f"measured_calls={stats['measured_calls']} "
            f"estimated_calls={stats['estimated_calls']}"
        )
        print(f"  counters: {stats}")
    else:
        print("decision model (Laya): not loaded, deterministic path only")
    print(f"perception model (LLM): {llm.USAGE.as_dict()}")
    try:
        llm.flush_ledger(llm.resolve_model() if not args.no_model else "")
    except Exception as exc:  # noqa: BLE001
        # Writing the usage ledger must never be able to fail a run: the
        # perception endpoint is optional and may simply not be running.
        print(f"usage ledger skipped: {exc}", file=sys.stderr)
    ledger_path = config.EVALUATION_DIR / "usage_ledger.json"
    if ledger_path.is_file() and engine is not None:
        ledger = json.loads(ledger_path.read_text(encoding="utf-8"))
        ledger["decision_model"] = {
            "engine": "laya",
            "checkpoint": str(config.LAYA_MODELS["multilingual"]),
            "device": config.LAYA_DEVICE,
            "autoregressive": False,
            "input_tokens": engine.STATS["input_tokens"],
            "output_tokens": engine.STATS["output_tokens"],
            "calls": engine.STATS["measured_calls"] + engine.STATS["estimated_calls"],
        }
        ledger_path.write_text(json.dumps(ledger, indent=2), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
