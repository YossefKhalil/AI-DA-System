#!/usr/bin/env python3
"""Compare a prediction file with a golden file.

``dataset/sample_output.csv`` is participant-facing, so this is a legitimate
public smoke test, not an evaluation shortcut: the same code path that writes
``output.csv`` is scored against the published sample answers.

Run:
    python -X utf8 code/score.py sample_prediction.csv dataset/sample_output.csv
"""

from __future__ import annotations

import argparse
import csv
import json
import os
from pathlib import Path

FIELDS = ("step_no", "phase", "system_id", "resource_id", "operation", "state", "evidence_id")
# For content recall we ignore step_no, which is a consequence of ordering.
KEY_FIELDS = ("phase", "system_id", "resource_id", "operation", "state", "evidence_id")


def _counts(steps: list[dict], fields: tuple[str, ...]) -> dict[tuple, int]:
    counts: dict[tuple, int] = {}
    for step in steps:
        key = tuple(step.get(field) for field in fields)
        counts[key] = counts.get(key, 0) + 1
    return counts


def load(path: Path) -> dict[str, dict]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return {row["case_id"]: row for row in csv.DictReader(handle)}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("prediction")
    parser.add_argument("golden", nargs="?", default="dataset/sample_output.csv")
    args = parser.parse_args(argv)

    prediction = load(Path(args.prediction))
    golden = load(Path(args.golden))

    total = len(golden)
    status_ok = exact_ok = count_ok = 0
    field_ok = field_total = 0
    step_ok = step_total = 0
    content_hit = content_total = content_extra = 0
    missing: list[str] = []
    wrong_status: list[str] = []
    missing_steps: list[str] = []

    for case_id, gold in sorted(golden.items()):
        pred = prediction.get(case_id)
        if pred is None:
            missing.append(case_id)
            continue
        if pred["deletion_status"] == gold["deletion_status"]:
            status_ok += 1
        else:
            wrong_status.append(f"{case_id} {gold['deletion_status']}->{pred['deletion_status']}")

        gold_steps = json.loads(gold["steps_json"])
        pred_steps = json.loads(pred["steps_json"]) if pred["steps_json"].strip() else []

        gold_counts = _counts(gold_steps, KEY_FIELDS)
        pred_counts = _counts(pred_steps, KEY_FIELDS)
        for key, want in gold_counts.items():
            content_total += want
            content_hit += min(want, pred_counts.get(key, 0))
            if pred_counts.get(key, 0) < want:
                missing_steps.append(f"{case_id} " + " ".join(str(part) for part in key))
        for key, got in pred_counts.items():
            content_extra += max(0, got - gold_counts.get(key, 0))

        if len(gold_steps) == len(pred_steps):
            count_ok += 1
        if gold["deletion_status"] == pred["deletion_status"] and gold_steps == pred_steps:
            exact_ok += 1

        for index in range(max(len(gold_steps), len(pred_steps))):
            step_total += 1
            if index >= len(gold_steps) or index >= len(pred_steps):
                field_total += len(FIELDS)
                continue
            fields_match = True
            for field in FIELDS:
                field_total += 1
                if gold_steps[index].get(field) == pred_steps[index].get(field):
                    field_ok += 1
                else:
                    fields_match = False
            if fields_match:
                step_ok += 1

    def pct(numerator: int, denominator: int) -> str:
        return f"{numerator}/{denominator} = {numerator / denominator:.2%}" if denominator else "n/a"

    print(f"cases:                 {total}")
    print(f"status accuracy:       {pct(status_ok, total)}")
    print(f"exact row match:       {pct(exact_ok, total)}")
    print(f"step-count match:      {pct(count_ok, total)}")
    print(f"step match (position): {pct(step_ok, step_total)}")
    print(f"field accuracy:        {pct(field_ok, field_total)}")
    print(f"step recall (content): {pct(content_hit, content_total)}")
    print(f"steps we invent:       {content_extra}")
    if missing:
        print(f"missing rows:          {len(missing)}")
    if missing_steps and os.environ.get("SHOW_MISSING"):
        print("golden steps not produced:")
        for line in missing_steps:
            print("  ", line)
    if wrong_status:
        print("wrong status:")
        for line in wrong_status:
            print("  ", line)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
