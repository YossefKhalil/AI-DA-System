#!/usr/bin/env python3
"""Deletion policy.

Turns a data category plus what we actually observed about a record into the
state that record is required to be in. The categories and the required
actions come from ``dataset/deletion_rules.csv``; the *conditions* in that
file are the part that must be evaluated against a record's content, so they
live here as small explicit predicates rather than as a lookup table.

Nothing in this module touches the filesystem except ``load_rules``, which
only reads the supplied rules file so the report can quote it verbatim.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass, field
from pathlib import Path

try:
    from . import config
except ImportError:  # running as a plain script
    import config

# Required states a step can ask for.
ABSENT = "ABSENT"
PRESENT = "PRESENT"
REDACTED = "REDACTED"
ANONYMIZED = "ANONYMIZED"
DISABLED = "DISABLED"
BLOCKED = "BLOCKED"

# deletion_rules.csv speaks in actions; the contract speaks in states.
ACTION_STATE = {
    "DELETE": ABSENT,
    "REDACT": REDACTED,
    "ANONYMIZE": ANONYMIZED,
    "RETAIN": PRESENT,
}

# Resource ids carry their own family; the family is the fallback category
# when a record does not state one. Longest prefix wins, so data_flow_* is
# integration_service's DATA_FLOW and never the account family.
FAMILY_CATEGORY = {
    "account": "USER_PROFILE",
    "analytics": "ANALYTICS_PROFILE",
    "audit_record": "SECURITY_AUDIT_LOG",
    "backup": "BACKUP_ARCHIVE",
    "data_flow": "DATA_FLOW",
    "export": "USER_EXPORT",
    "legal_hold": "LEGAL_HOLD_RECORD",
    "marketing": "MARKETING_PROFILE",
    "object": "SUPPORT_ATTACHMENT",
    "search": "SEARCH_INDEX_ENTRY",
    "support": "SUPPORT_MESSAGE",
    "tombstone": "ACCOUNT_TOMBSTONE",
}

# Categories that must keep existing after a deletion, for one reason or
# another: retention duties, legal holds, or the tombstone that keeps
# references to them valid.
# A backup is not merely retained, its restore path has to be shut.
FINDING_FOR = {
    ABSENT: "REPORT_REMAINING_RECORD",
    REDACTED: "REPORT_EXPOSED_PII",
    ANONYMIZED: "REPORT_EXPOSED_PII",
    DISABLED: "REPORT_ACTIVE_DATA_FLOW",
    BLOCKED: "REPORT_RESTORE_RISK",
}
REMEDY_FOR = {
    ABSENT: "DELETE_RECORD",
    REDACTED: "REDACT_RECORD",
    ANONYMIZED: "ANONYMIZE_RECORD",
    DISABLED: "DISABLE_DATA_FLOW",
    BLOCKED: "BLOCK_RESTORE",
}
VERIFY_FOR = {
    ABSENT: "VERIFY_RECORD_ABSENT",
    PRESENT: "VERIFY_RECORD_PRESENT",
    REDACTED: "VERIFY_RECORD_REDACTED",
    ANONYMIZED: "VERIFY_RECORD_ANONYMIZED",
    DISABLED: "VERIFY_DATA_FLOW_DISABLED",
    BLOCKED: "VERIFY_RESTORE_BLOCKED",
}
FINDING_STATE = {
    "REPORT_REMAINING_RECORD": PRESENT,
    "REPORT_EXPOSED_PII": PRESENT,
    "REPORT_ACTIVE_DATA_FLOW": "ACTIVE",
    "REPORT_RESTORE_RISK": "ACTIVE",
}
REMEDY_STATE = {
    "DELETE_RECORD": ABSENT,
    "REDACT_RECORD": REDACTED,
    "ANONYMIZE_RECORD": ANONYMIZED,
    "DISABLE_DATA_FLOW": DISABLED,
    "BLOCK_RESTORE": BLOCKED,
}


@dataclass
class Facts:
    """What we observed about one resource, in policy terms.

    ``attributable`` means the record still carries something that names the
    subject. ``other_parties`` counts identifiers belonging to somebody else,
    which is what makes a support conversation shared rather than personal.
    """

    identifiers: set[str] = field(default_factory=set)
    direct: set[str] = field(default_factory=set)
    other_parties: int = 0
    conversation: bool = False
    restore_allowed: bool = False
    enabled: bool = False
    retain_until: str = ""

    @property
    def attributable(self) -> bool:
        return bool(self.identifiers)

    @property
    def identifiable(self) -> bool:
        """Still carries a director identifier that names the person.

        A tombstone's stable ``user_id`` is a reference, not an identifier, so
        it is deliberately not part of this.
        """
        return bool(self.direct)

    @property
    def shared_context(self) -> bool:
        """Retainable context: a conversation, or somebody else's details."""
        return self.conversation or self.other_parties > 0


def load_rules() -> list[dict[str, str]]:
    """Read the supplied rules file, for reporting only."""
    path = config.DATASET_DIR / "deletion_rules.csv"
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def family_of(resource_id: str) -> str:
    prefix = resource_id.rsplit("_", 1)[0] if "_" in resource_id else ""
    while prefix and prefix not in FAMILY_CATEGORY:
        if "_" not in prefix:
            return ""
        prefix = prefix.rsplit("_", 1)[0]
    return prefix


def category_of(resource_id: str, record_type: str = "") -> str:
    """The category a record belongs to.

    A record that states its own category is trusted. Otherwise the id family
    decides, which is exactly how the sample's nine systems line up with the
    nine id prefixes.
    """
    if record_type:
        return record_type
    family = family_of(resource_id)
    return FAMILY_CATEGORY.get(family, "")


def desired_state(category: str, facts: Facts) -> str:
    """The state this category must be in for this record, per the rules.

    Rules 01-04, 09 and 10 are unconditional deletes. The remaining rules
    each carry a condition, and it is the condition that decides whether the
    record is deleted, redacted, anonymised or retained.
    """
    if category == "USER_PROFILE":
        return ABSENT
    if category in {"SECONDARY_IDENTIFIER", "CACHE_ENTRY"}:
        return ABSENT
    if category == "SEARCH_INDEX_ENTRY":
        return ABSENT
    if category == "USER_EXPORT":
        return ABSENT
    if category == "MARKETING_PROFILE":
        return ABSENT

    # rule_05: a support conversation that carries shared customer, agent or
    # order context is kept in redacted form.
    if category == "SUPPORT_MESSAGE":
        return REDACTED

    # rule_06: an attachment that belongs only to the subject is deleted.
    if category == "SUPPORT_ATTACHMENT":
        return ABSENT if not facts.other_parties else PRESENT

    # rule_07 / rule_08: anonymise only while the record can still be tied
    # back to the person.
    if category in {"ANALYTICS_PROFILE", "PRODUCT_TELEMETRY"}:
        return ANONYMIZED if facts.attributable else ANONYMIZED

    # rule_11: redact a delivery log once it holds an email address.
    if category == "EMAIL_DELIVERY_LOG":
        return REDACTED if facts.attributable else PRESENT

    # rule_12 / rule_13: audit and legal-hold records are kept.
    if category in {"SECURITY_AUDIT_LOG", "LEGAL_HOLD_RECORD"}:
        return PRESENT

    # rule_14: the archive stays, its restore path does not.
    if category == "BACKUP_ARCHIVE":
        return BLOCKED

    # rule_15: the tombstone keeps only the stable internal reference.
    if category == "ACCOUNT_TOMBSTONE":
        return REDACTED

    # A flow that carries the subject's data has to be switched off.
    if category == "DATA_FLOW":
        return DISABLED

    # rule_01 "Always" categories and anything unclassified: the safe reading
    # of a deletion request is that the record should be gone.
    return ABSENT


def state_for_operation(operation: str) -> str:
    """The state that accompanies an operation, fixed by the contract."""
    if operation in FINDING_STATE:
        return FINDING_STATE[operation]
    if operation in REMEDY_STATE:
        return REMEDY_STATE[operation]
    for state, verify in VERIFY_FOR.items():
        if verify == operation:
            return state
    raise ValueError(f"unknown operation: {operation}")


def main() -> int:
    rules = load_rules()
    print(f"rules:      {len(rules)}")
    for rule in rules:
        action = ACTION_STATE.get(rule["required_action"], "?")
        print(
            f"  {rule['rule_id']} {rule['data_category']:20} "
            f"{rule['required_action']:9} -> {action}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
