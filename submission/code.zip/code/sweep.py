#!/usr/bin/env python3
"""Find the decision model's best settings on the public sample.

Every knob is swept in process, so the checkpoint is loaded once and 60
configurations cost one model load. Configurations are evaluated five at a
time; after each fifth the best-so-far is printed and the next five are drawn
around it, so the search narrows instead of walking a fixed grid.

Run:
    python -X utf8 code/sweep.py            # 60 configurations, 12 batches of 5
    python -X utf8 code/sweep.py --count 20 --batch 5
"""

from __future__ import annotations

import argparse
import csv
import json
import random
from pathlib import Path

try:
    from . import config, evidence, laya_engine, main, observe, resolve
except ImportError:  # running as a plain script
    import config
    import evidence
    import laya_engine
    import main
    import observe
    import resolve

# Space. The checkpoint caps the input at 8192 tokens (encoder
# max_position_embeddings and tokenizer model_max_length both say 8192), so
# that is the ceiling rather than 32k. The option budget is swept up to 2048
# because the treatment question carries six options and long rule text.
SPACE = {
    "LAYA_MIN_CONFIDENCE": [0.50, 0.70, 0.80],
    "LAYA_MAX_LEN": [1024, 2048, 4096, 8192],
    "LAYA_HEAD_MAX_LEN": [256, 1024, 2048],
    "LAYA_BIND_THRESHOLD": [0.80, 0.88, 0.94],
    "LAYA_BIND_MARGIN": [0.15, 0.25, 0.35],
    "LAYA_JUDGE_CONFIDENCE": [0.60, 0.80, 0.90],
    # The two knobs that control the binding error itself: how many candidates
    # the model is shown, and how many bindings it may add.
    "CANDIDATE_CAP": [2, 4, 10],
    "BIND_MAX_PER_CASE": [1, 2, 99],
}


def sample_coarse(rng: random.Random) -> dict:
    return {key: rng.choice(values) for key, values in SPACE.items()}


def mutate(parent: dict, rng: random.Random) -> dict:
    """A child: one or two knobs moved to a neighbouring value on the grid."""
    child = dict(parent)
    for key in rng.sample(list(SPACE), rng.choice([1, 1, 2])):
        values = SPACE[key]
        position = values.index(child[key]) if child[key] in values else 0
        step = rng.choice([-1, 1])
        child[key] = values[min(max(position + step, 0), len(values) - 1)]
    return child


def rank(item: tuple[dict, dict]) -> tuple:
    """Status first, then exact rows, then recall, then fewest invented steps."""
    metrics = item[1]
    return (metrics["status"], metrics["exact"], metrics["recall"], -metrics["invented"])


def load_sample():
    requests = {}
    with (config.DATASET_DIR / "sample_deletion_requests.csv").open(
        encoding="utf-8-sig", newline=""
    ) as handle:
        for row in csv.DictReader(handle):
            requests[row["case_id"]] = row
    golden = {}
    with (config.DATASET_DIR / "sample_output.csv").open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            golden[row["case_id"]] = row
    return requests, golden


def evaluate(rows, golden) -> dict:
    total = len(golden)
    status_ok = exact_ok = 0
    recall_hit = recall_total = invented = 0
    for case_id, gold in golden.items():
        status, steps = rows[case_id]
        gold_steps = json.loads(gold["steps_json"])
        if status == gold["deletion_status"]:
            status_ok += 1
        if status == gold["deletion_status"] and steps == gold_steps:
            exact_ok += 1
        gold_keys = [
            (s["phase"], s["system_id"], s["resource_id"], s["operation"], s["state"], s["evidence_id"])
            for s in gold_steps
        ]
        our_keys = [
            (s["phase"], s["system_id"], s["resource_id"], s["operation"], s["state"], s["evidence_id"])
            for s in steps
        ]
        pool = list(our_keys)
        for key in gold_keys:
            recall_total += 1
            if key in pool:
                pool.remove(key)
                recall_hit += 1
        invented += len(pool)
    return {
        "status": status_ok / total,
        "exact": exact_ok / total,
        "recall": recall_hit / recall_total if recall_total else 0.0,
        "invented": invented,
    }


def apply(cfg: dict) -> None:
    for key, value in cfg.items():
        setattr(config, key, value)


def main_sweep(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--count", type=int, default=60)
    parser.add_argument("--batch", type=int, default=5)
    parser.add_argument("--out", default="")
    args = parser.parse_args(argv)

    requests, golden = load_sample()
    records = evidence.load_records()
    observe.set_file_weights(records)
    captures = observe.load_captures()
    cases = resolve.load_cases("sample_deletion_requests.csv")
    if not laya_engine.available():
        print("no decision model available")
        return 1

    rng = random.Random(20261026)
    results: list[tuple[dict, dict]] = []
    generations = max(1, args.count // args.batch)
    population = [sample_coarse(rng) for _ in range(args.batch)]

    for generation in range(1, generations + 1):
        scored: list[tuple[dict, dict]] = []
        for cfg in population:
            apply(cfg)
            produced = {
                case_id: (status, steps)
                for case_id, status, steps in main.audit_cases(
                    cases, records, captures, use_model=True
                )
            }
            metrics = evaluate(produced, golden)
            scored.append((cfg, metrics))
            results.append((cfg, metrics))
            print(
                f"  gen {generation:2}  status={metrics['status']:.3f} "
                f"exact={metrics['exact']:.3f} recall={metrics['recall']:.3f} "
                f"invented={metrics['invented']:3}  {cfg}",
                flush=True,
            )
        scored.sort(key=rank, reverse=True)
        champion = scored[0]
        print(
            f"=== generation {generation} best: status={champion[1]['status']:.3f} "
            f"exact={champion[1]['exact']:.3f} recall={champion[1]['recall']:.3f} "
            f"invented={champion[1]['invented']}  {champion[0]}",
            flush=True,
        )
        if generation < generations:
            elite = [cfg for cfg, _ in scored[:3]]
            population = [mutate(rng.choice(elite), rng) for _ in range(args.batch)]

    results.sort(key=rank, reverse=True)
    print("\nTOP 10")
    for cfg, metrics in results[:10]:
        print(
            f"  status={metrics['status']:.3f} exact={metrics['exact']:.3f} "
            f"recall={metrics['recall']:.3f} invented={metrics['invented']:3}  {cfg}"
        )
    out = Path(args.out) if args.out else config.EVALUATION_DIR / "sweep_results.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(
            [{"config": cfg, "metrics": metrics} for cfg, metrics in results],
            indent=2,
        ),
        encoding="utf-8",
    )
    print(f"\nwrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main_sweep())
