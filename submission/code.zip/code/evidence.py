#!/usr/bin/env python3
"""Evidence parsing.

Turns the files listed in the evidence manifest into uniform Record
objects. Nothing here matches a record to a person - that is identity.py's
job - and nothing here applies policy. This module only answers:

    what records exist, where did each come from, when was it captured?

Supported inputs: JSON exports, SQLite .sql dumps, logs, plain text, PDF
(with embedded text) and screenshots (via the cached vision transcription
in model_tasks.py).

CLI:
    python code/evidence.py summary
"""

from __future__ import annotations

import csv
import json
import re
import sqlite3
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Iterator

try:
    from . import config
except ImportError:  # pragma: no cover - direct script execution
    import config  # type: ignore


# ------------------------------------------------------------- vocabulary --

# resource-id prefix -> owning system. This is the platform's naming
# convention, read off the dataset, and it is only ever a fallback: a
# record's own system field always wins.
PREFIX_SYSTEM = {
    "account": "account_service",
    "analytics": "analytics_platform",
    "audit_record": "security_service",
    "backup": "backup_service",
    "data_flow": "integration_service",
    "export": "export_service",
    "legal_hold": "legal_service",
    "marketing": "marketing_platform",
    "object": "object_storage",
    "search": "search_service",
    "support": "support_platform",
    "tombstone": "identity_service",
}

# Longest prefix first, so "data_flow_9" resolves as integration_service
# rather than stopping at "data".
_PREFIXES_BY_LENGTH = sorted(PREFIX_SYSTEM, key=len, reverse=True)

# Recorded service names that differ from the platform's canonical system id.
# Only consulted when the resource id carries no known prefix.
SYSTEM_ALIASES = {
    "account_history_service": "account_service",
    "backup_restore_service": "backup_service",
    "customer_account_service": "account_service",
    "customer_export_service": "export_service",
    "customer_search_primary_capture": "search_service",
    "downstream_delivery_service": "export_service",
    "search_index_service": "search_service",
    "security_audit_service": "security_service",
    "support_replica": "support_platform",
    "support_storage_service": "support_platform",
}

EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
HASH_RE = re.compile(r"\b[0-9a-fA-F]{64}\b")
USER_RE = re.compile(r"\buser_[0-9]+\b")
PHONE_RE = re.compile(r"(?:\+\d[\d\s().\-]{7,}\d)")
RESOURCE_RE = re.compile(
    r"\b(?:"
    + "|".join(sorted(PREFIX_SYSTEM, key=len, reverse=True))
    + r")_[0-9]+\b"
)
ISO_RE = re.compile(r"\b(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z)\b")
KV_RE = re.compile(r"([A-Za-z_][A-Za-z0-9_]*)=(\"[^\"]*\"|'[^']*'|[^\s,;]+)")

# Attributes that name another resource, and so may be followed as links.
FOREIGN_KEYS = frozenset(
    {
        "account_resource_id",
        "linked_resource_id",
        "parent_resource_id",
        "source_resource_id",
        "target_resource_id",
    }
)

TEXT_SUFFIXES = {".log", ".txt", ".md", ".csv"}
JSON_SUFFIXES = {".json"}
SQL_SUFFIXES = {".sql"}
PDF_SUFFIXES = {".pdf"}
IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp", ".gif"}


def system_for(resource_id: str) -> str:
    """Canonical system id for a resource, from the platform's id convention."""
    for prefix in _PREFIXES_BY_LENGTH:
        if resource_id.startswith(prefix + "_"):
            return PREFIX_SYSTEM[prefix]
    return "unknown"


_LOG_LEVELS = {"DEBUG", "INFO", "WARN", "WARNING", "ERROR", "TRACE", "FATAL"}


def normalize_system(recorded: str, resource_id: str) -> str:
    """Canonical system id for a record.

    The resource-id prefix wins whenever it is known, because the platform's
    canonical system ids are exactly the id prefixes. A recorded service name
    is only consulted when the id carries no known prefix, and a log level is
    never accepted as a system.
    """
    derived = system_for(resource_id) if resource_id else "unknown"
    if derived != "unknown":
        return derived
    name = (recorded or "").strip().lower()
    if not name or name.upper() in _LOG_LEVELS:
        return ""
    return SYSTEM_ALIASES.get(name, name)


# The data categories the deletion policy names. A record's own type is a
# category only when it appears here; anything else (an event name, a store
# name, a trace id) is noise and the id family decides instead.
CATEGORIES = frozenset(
    {
        "ACCOUNT_TOMBSTONE",
        "ANALYTICS_PROFILE",
        "BACKUP_ARCHIVE",
        "CACHE_ENTRY",
        "DATA_FLOW",
        "DOCUMENT",
        "EMAIL_DELIVERY_LOG",
        "LEGAL_HOLD_RECORD",
        "MARKETING_PROFILE",
        "PRODUCT_TELEMETRY",
        "SEARCH_INDEX_ENTRY",
        "SECONDARY_IDENTIFIER",
        "SECURITY_AUDIT_LOG",
        "SUPPORT_ATTACHMENT",
        "SUPPORT_MESSAGE",
        "USER_EXPORT",
        "USER_PROFILE",
    }
)

# Inventory snapshots name their table after the category it holds.
TABLE_CATEGORY = {
    "backup_restore_entries": "BACKUP_ARCHIVE",
    "connector_subscriptions": "DATA_FLOW",
    "customer_analytics_profiles": "ANALYTICS_PROFILE",
    "customer_exports": "USER_EXPORT",
    "customer_profiles": "USER_PROFILE",
    "customer_search_documents": "SEARCH_INDEX_ENTRY",
    "security_audit_records": "SECURITY_AUDIT_LOG",
    "support_records": "SUPPORT_MESSAGE",
}


def normalize_category(value: Any) -> str:
    """The value as a data category, or an empty string when it is not one."""
    text = str(value or "").strip()
    return text if text in CATEGORIES else ""


def identifiers_in(text: str) -> tuple[str, ...]:
    """Every identifier-shaped token in a blob of text, de-duplicated."""
    found = (
        EMAIL_RE.findall(text)
        + HASH_RE.findall(text)
        + USER_RE.findall(text)
        + PHONE_RE.findall(text)
    )
    return tuple(dict.fromkeys(value.strip() for value in found if value.strip()))


# ---------------------------------------------------------------- record ----

@dataclass
class Record:
    """One row/object/document observed in one evidence file."""

    file_id: str
    captured_at: str
    system: str
    resource_id: str
    record_type: str = ""
    state: str = ""
    attributes: dict[str, Any] = field(default_factory=dict)
    text: str = ""

    @property
    def identifiers(self) -> tuple[str, ...]:
        blob = self.text or json.dumps(self.attributes, ensure_ascii=False, default=str)
        return identifiers_in(blob)

    def alias_ids(self) -> Iterator[str]:
        """Other resource ids this record points at through a foreign key.

        Only attributes that name another resource are followed. Scanning
        every string value would drag in unrelated ids mentioned in the same
        payload, which is how a metrics blob ends up claiming somebody else's
        analytics profile.
        """
        for name, value in self.attributes.items():
            if name.rsplit(".", 1)[-1] not in FOREIGN_KEYS:
                continue
            if isinstance(value, str):
                for rid in RESOURCE_RE.findall(value):
                    if rid != self.resource_id:
                        yield rid


# --------------------------------------------------------------- helpers ----

def _flatten(value: Any, prefix: str = "") -> dict[str, Any]:
    out: dict[str, Any] = {}
    if isinstance(value, dict):
        for key, item in value.items():
            _flatten_into(out, item, f"{prefix}.{key}" if prefix else str(key))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            _flatten_into(out, item, f"{prefix}[{index}]")
    elif value is not None:
        out[prefix] = value
    return out


def _flatten_into(out: dict[str, Any], value: Any, key: str) -> None:
    if isinstance(value, (dict, list)):
        out.update(_flatten(value, key))
    elif value is not None:
        out[key] = value


def _scalar(value: Any) -> str:
    return "" if value is None else str(value)


def _first(attributes: dict[str, Any], *names: str) -> str:
    for name in names:
        for key, value in attributes.items():
            if key.split(".")[-1] == name and value not in (None, ""):
                return _scalar(value)
    return ""


def _trailing_json(text: str) -> Any | None:
    """Decode a JSON value that starts at the beginning of `text`.

    Log lines are often `2026-...Z {"service":"...","resource_id":"..."}`.
    Trailing text after the JSON value is ignored.
    """
    try:
        value, _ = json.JSONDecoder().raw_decode(text)
    except ValueError:
        return None
    return value


# ------------------------------------------------------------- json walk ----

def _records_from_json(
    node: Any,
    file_id: str,
    captured_at: str,
    source: str,
    system: str = "",
) -> Iterator[Record]:
    if isinstance(node, dict):
        # A snapshot wrapper carries its own capture time and store.
        local_time = _scalar(node.get("captured_at") or node.get("observed_at") or captured_at)
        local_system = system or _scalar(
            node.get("data_store") or node.get("store") or node.get("system") or node.get("service")
        )
        resource_id = node.get("resource_id")
        if isinstance(resource_id, str) and resource_id:
            attributes = _flatten(node)
            yield Record(
                file_id=file_id,
                captured_at=local_time,
                system=normalize_system(local_system, resource_id),
                resource_id=resource_id,
                record_type=normalize_category(
                    node.get("record_type") or node.get("category")
                ),
                state=_scalar(node.get("state") or node.get("result") or node.get("status")),
                attributes=attributes,
                text=json.dumps(node, ensure_ascii=False, default=str),
            )
        for key, value in node.items():
            if key in {"records", "snapshots", "service_exports", "profiles", "exports", "items"} \
                    or isinstance(value, (dict, list)):
                yield from _records_from_json(value, file_id, local_time, source, local_system)
    elif isinstance(node, list):
        for item in node:
            yield from _records_from_json(item, file_id, captured_at, source, system)


# ------------------------------------------------------------------- sql ----

def _records_from_sql(path: Path, file_id: str, captured_at: str) -> Iterator[Record]:
    connection = sqlite3.connect(":memory:")
    try:
        connection.executescript(path.read_text(encoding="utf-8", errors="ignore"))
        tables = [
            row[0]
            for row in connection.execute("select name from sqlite_master where type='table'")
        ]
        for table in tables:
            columns = [row[1] for row in connection.execute(f"pragma table_info('{table}')")]
            if not columns:
                continue
            for row in connection.execute(f"select * from '{table}'"):
                raw = dict(zip(columns, row))
                attributes: dict[str, Any] = {}
                for key, value in raw.items():
                    if isinstance(value, str) and value.strip().startswith(("{", "[")):
                        try:
                            attributes.update(_flatten(json.loads(value)))
                            continue
                        except ValueError:
                            pass
                    attributes[key] = value
                resource_id = _first(attributes, "resource_id") or _first(attributes, "id")
                if not resource_id:
                    continue
                yield Record(
                    file_id=file_id,
                    captured_at=_first(attributes, "captured_at", "observed_at", "updated_at")
                    or captured_at,
                    system=normalize_system(
                        _first(attributes, "origin_system", "system", "service"), resource_id
                    ),
                    resource_id=resource_id,
                    record_type=normalize_category(
                        _first(attributes, "record_type", "category")
                    )
                    or TABLE_CATEGORY.get(table, ""),
                    state=_first(attributes, "state", "status", "result"),
                    attributes=attributes,
                    text=json.dumps(raw, ensure_ascii=False, default=str),
                )
    except sqlite3.Error:
        return
    finally:
        connection.close()


# --------------------------------------------------------------- text/log ---

def _records_from_text(
    text: str, file_id: str, captured_at: str, source: str
) -> Iterator[Record]:
    """Line-oriented evidence, with trace ids merged across lines.

    A log often puts the identifier on one line and the resource id on a
    later line of the same trace, so lines are grouped by trace_id first.
    """
    grouped: dict[str, dict[str, Any]] = {}
    loose: list[dict[str, Any]] = []

    for line in text.splitlines():
        resource_ids = RESOURCE_RE.findall(line)
        attributes = {
            key: value.strip("\"'\\") for key, value in KV_RE.findall(line)
        }
        brace = line.find("{")
        if brace >= 0:
            payload = _trailing_json(line[brace:])
            if payload is not None:
                for key, value in _flatten(payload).items():
                    attributes.setdefault(key, _scalar(value))
        if "|" in line:
            parts = [part.strip() for part in line.strip(" -").split("|")]
            if len(parts) >= 4:
                attributes.setdefault("system", parts[1])
                attributes.setdefault("record_type", parts[3])
                if len(parts) >= 5:
                    attributes.setdefault("state", parts[4])
                if len(parts) >= 6:
                    attributes.setdefault("identifier", parts[5])
        observed = ISO_RE.search(line)
        trace_id = attributes.get("trace_id") or attributes.get("requestId")
        # A line with neither a resource id nor a trace is noise. A line with
        # a trace id is kept even when it names no resource, because that is
        # where the subject's identifier usually appears: the lookup_started
        # line names the person, the completed line names the resource.
        if not resource_ids and not trace_id:
            continue
        entry = {
            "resource_ids": resource_ids,
            "attributes": attributes,
            "line": line,
            "captured": observed.group(1) if observed else captured_at,
        }
        if trace_id:
            grouped.setdefault(trace_id, {"entries": []})["entries"].append(entry)
        else:
            loose.append(entry)

    def emit(entries: list[dict[str, Any]]) -> Iterator[Record]:
        attributes: dict[str, Any] = {}
        resource_ids: list[str] = []
        for entry in entries:
            attributes.update(entry["attributes"])
            for rid in entry["resource_ids"]:
                if rid not in resource_ids:
                    resource_ids.append(rid)
        joined = "\n".join(entry["line"] for entry in entries)
        captured = next((e["captured"] for e in entries if e["captured"]), captured_at)
        system = _scalar(attributes.get("system") or attributes.get("service"))
        for rid in resource_ids:
            yield Record(
                file_id=file_id,
                captured_at=captured,
                system=normalize_system(system, rid),
                resource_id=rid,
                record_type=normalize_category(
                    attributes.get("record_type") or attributes.get("event")
                ),
                state=_scalar(attributes.get("state") or attributes.get("result")),
                attributes=attributes,
                text=joined,
            )

    for bucket in grouped.values():
        yield from emit(bucket["entries"])
    # Loose lines have no trace to group them, so each line keeps its own
    # attributes. Merging them would smear one record's category and state
    # across every resource named in the file.
    for entry in loose:
        yield from emit([entry])


# ------------------------------------------------------------------- pdf ----

def _records_from_pdf(path: Path, file_id: str, captured_at: str) -> Iterator[Record]:
    try:
        from pypdf import PdfReader
    except ImportError:
        return
    try:
        text = "\n".join((page.extract_text() or "") for page in PdfReader(str(path)).pages)
    except Exception:  # noqa: BLE001 - unreadable pdf is not fatal
        return
    ids = RESOURCE_RE.findall(text)
    if not ids:
        yield Record(
            file_id=file_id,
            captured_at=captured_at,
            system="",
            resource_id="",
            record_type="DOCUMENT",
            text=text,
        )
        return
    for rid in dict.fromkeys(ids):
        yield Record(
            file_id=file_id,
            captured_at=captured_at,
            system=system_for(rid),
            resource_id=rid,
            record_type="DOCUMENT",
            text=text,
        )


# ---------------------------------------------------------------- images ----

def _records_from_image(file_id: str, captured_at: str) -> Iterator[Record]:
    """Read the cached vision transcription for a screenshot, if present.

    The transcription is produced by model_tasks.extract_all_images and
    stored outside the dataset. A missing transcription is not an error.
    """
    cache = config.CACHE_DIR / "vision" / "extracts.json"
    if not cache.is_file():
        return
    try:
        payload = json.loads(cache.read_text(encoding="utf-8"))
    except ValueError:
        return
    entry = payload.get(file_id)
    if not entry or not entry.get("ok"):
        return
    data = entry.get("json") or {}
    blob = json.dumps(data, ensure_ascii=False)
    resource_ids = [rid for rid in (data.get("resource_ids") or []) if rid]
    resource_ids += RESOURCE_RE.findall(blob)
    for rid in dict.fromkeys(resource_ids):
        yield Record(
            file_id=file_id,
            captured_at=captured_at,
            system=normalize_system(_scalar(data.get("system")), rid),
            resource_id=rid,
            record_type="SCREENSHOT",
            text=entry.get("text") or blob,
        )


# ------------------------------------------------------------------- api ----

def manifest() -> list[dict[str, str]]:
    path = config.DATASET_DIR / "evidence_files.csv"
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def records_for_file(row: dict[str, str]) -> Iterator[Record]:
    file_id = row.get("file_id", "")
    captured_at = row.get("captured_at", "")
    path = (config.DATASET_DIR / row.get("file_path", "")).resolve()
    suffix = path.suffix.lower()
    if not path.is_file():
        return
    if suffix in JSON_SUFFIXES:
        try:
            node = json.loads(path.read_text(encoding="utf-8", errors="ignore"))
        except ValueError:
            return
        yield from _records_from_json(node, file_id, captured_at, path.name)
    elif suffix in SQL_SUFFIXES:
        yield from _records_from_sql(path, file_id, captured_at)
    elif suffix in PDF_SUFFIXES:
        yield from _records_from_pdf(path, file_id, captured_at)
    elif suffix in IMAGE_SUFFIXES:
        yield from _records_from_image(file_id, captured_at)
    elif suffix in TEXT_SUFFIXES:
        yield from _records_from_text(
            path.read_text(encoding="utf-8", errors="ignore"), file_id, captured_at, path.name
        )


def load_records() -> list[Record]:
    out: list[Record] = []
    for row in manifest():
        out.extend(records_for_file(row))
    return out


# ------------------------------------------------------------------- cli ----

def main(argv: Iterable[str]) -> int:
    argv = list(argv)
    command = argv[0] if argv else "summary"
    if command != "summary":
        print(f"unknown command: {command}", file=sys.stderr)
        return 2

    records = load_records()
    by_system: dict[str, int] = {}
    by_file: dict[str, int] = {}
    for record in records:
        by_system[record.system] = by_system.get(record.system, 0) + 1
        by_file[record.file_id] = by_file.get(record.file_id, 0) + 1
    print(f"files in manifest: {len(manifest())}")
    print(f"records parsed:    {len(records)}")
    print(f"distinct ids:      {len({r.resource_id for r in records if r.resource_id})}")
    print("\nby system")
    for system, count in sorted(by_system.items(), key=lambda x: -x[1]):
        print(f"  {system:22} {count}")
    print("\nby file")
    for file_id, count in sorted(by_file.items()):
        print(f"  {file_id:12} {count}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
