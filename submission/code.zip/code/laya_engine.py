#!/usr/bin/env python3
"""The decision model: Laya, as typed decisions.

This module owns the **decision seat**. It answers three questions and nothing
else:

    intent   choice  DELETE | VERIFY_DELETION | NON_DELETION
    bind     noul    one yes/no per candidate record
    judge    choice  one of six required states per record, plus the verdict

Laya is non-autoregressive: a decision is one forward pass and **no generated
tokens** -- the answer is a label with a calibrated probability over the
options the caller supplies. That is why it is the decision model here and the
35B LLM is not: the LLM's seat is perception (screenshots), in `model_tasks.py`.

Nothing is hard-coded to a machine. The checkpoint directory comes from
`config.LAYA_MODELS`, overridable with `LAYA_DIR` / `LAYA_MULTILINGUAL`, and
the confidence gate from `LAYA_MIN_CONFIDENCE`. Code supplies the options and
enforces the hard constraints; Laya picks. An answer below the gate is
abstained on, and the caller keeps its deterministic reading instead.
"""

from __future__ import annotations

import os
from functools import lru_cache

try:
    from . import config, pack
except ImportError:  # running as a plain script
    import config
    import pack

# Per-run counters, so a run can report what the decision model actually did.
STATS = {
    "intent_calls": 0,
    "intent_abstained": 0,
    # Token accounting for the decision model. Laya is non-autoregressive, so
    # the output side is structurally zero: a decision is one forward pass over
    # the options, not generated text.
    "input_tokens": 0,
    "output_tokens": 0,
    "state_tokens_dropped": 0,
    "truncated_calls": 0,
    "measured_calls": 0,
    "estimated_calls": 0,
    "bind_calls": 0,
    "judge_calls": 0,
    "scan_calls": 0,
    "scan_flagged": 0,
    "scan_bound": 0,
    "added": 0,
    "agree": 0,
    "disagree": 0,
    "abstained": 0,
}

INTENT_LABELS = ("DELETE", "VERIFY_DELETION", "NON_DELETION")

INTENT_CRITERIA = {
    "DELETE": (
        "the customer wants the account or their personal data erased, deleted, "
        "closed, removed, purged, or no longer kept"
    ),
    "VERIFY_DELETION": (
        "the customer says a deletion was already requested and asks whether it "
        "has finished, or asks for an unfinished one to be completed because "
        "data may still remain"
    ),
    "NON_DELETION": (
        "the customer wants something other than deletion: a copy or export of "
        "their data, a correction to a field such as a name, phone number or "
        "email address, to stop marketing or promotional email, help signing in, "
        "or a general question. If the account is to be kept, it is NON_DELETION "
        "even when the message mentions removing something, such as being taken "
        "off a mailing list"
    ),
}

STATE_CRITERIA = {
    "ABSENT": "the record must be deleted and must no longer exist",
    "PRESENT": "the record must be kept as it is, for a retention period or a legal hold",
    "REDACTED": "the record is kept but its identifying fields must be removed",
    "ANONYMIZED": "the record is kept but must no longer be linkable to the person",
    "DISABLED": "a data flow that can copy or recreate the person's data must be switched off",
    "BLOCKED": "a backup that can still restore the person's data must have its restore path blocked",
}

# Only these have a conditional rule in the supplied policy. Everything else is
# an unconditional delete or retain -- a lookup, not a decision -- so code keeps
# it and the decision model is not asked.
CONDITIONAL_RULES = {
    "SUPPORT_MESSAGE": (
        "REDACT if the conversation carries shared customer, agent or order "
        "context that must be retained; otherwise it is deleted"
    ),
    "SUPPORT_ATTACHMENT": (
        "DELETE if the attachment belongs only to the deletion subject"
    ),
    "ANALYTICS_PROFILE": "ANONYMIZE while the record is still attributable to a user",
    "PRODUCT_TELEMETRY": "ANONYMIZE while the record is still attributable to a user",
    "EMAIL_DELIVERY_LOG": "REDACT while the log contains a user email address",
    "BACKUP_ARCHIVE": "RETAIN, but restore access must be blocked",
    "ACCOUNT_TOMBSTONE": (
        "REDACT, keeping only the stable internal user reference"
    ),
}

VERDICT_CRITERIA = {
    "COMPLETE": "every record is already in the state it must be in",
    "INCOMPLETE": "at least one record is not yet in the state it must be in",
}


def _checkpoint():
    """The checkpoint directory to load, or None."""
    for path in config.LAYA_MODELS.values():
        if (path / "model.safetensors").is_file():
            return path
    return None


def available() -> bool:
    """True when Laya is importable and a local checkpoint is present."""
    try:
        import laya  # noqa: F401
    except Exception:  # noqa: BLE001 - any import failure means "not available"
        return False
    return _checkpoint() is not None


@lru_cache(maxsize=1)
def _agent():
    """The process-wide decision model, loaded from the local checkpoint."""
    import laya

    path = _checkpoint()
    if path is None:
        raise RuntimeError("no local Laya checkpoint found")
    return laya.load(str(path), device=config.LAYA_DEVICE)


def record_usage(result, sent_tokens: int) -> None:
    """Accumulate the decision model's token consumption: tokens in and out.

    Tokens in are taken from what the model reports when it reports anything,
    and otherwise measured from the payload we actually sent, so the figure is
    always grounded rather than assumed. Tokens out are zero by construction:
    Laya scores the options in one forward pass and never generates text, which
    is the whole reason it costs nothing per case.
    """
    usage = {}
    if isinstance(result, dict):
        usage = result.get("usage") or {}
    prompt = usage.get("prompt_tokens", usage.get("input_tokens"))
    completion = usage.get("completion_tokens", usage.get("output_tokens"))
    if prompt is None:
        STATS["input_tokens"] += sent_tokens
        STATS["estimated_calls"] += 1
    else:
        STATS["input_tokens"] += int(prompt)
        STATS["measured_calls"] += 1
    STATS["output_tokens"] += int(completion or 0)
    # Laya reports its own truncation: state_tokens_dropped is how much of the
    # state a question's head budget had to give up. Without this the loss is
    # invisible, which is how a silent truncation becomes a wrong answer.
    STATS["state_tokens_dropped"] += int(usage.get("state_tokens_dropped") or 0)
    if usage.get("truncated"):
        STATS["truncated_calls"] += 1


def ask(state, questions: dict) -> dict:
    """One forward pass, with the payload packed under the context budget."""
    limit = max(128, pack.budget() - question_cost(questions))
    packed = pack.pack([pack.Section(pack.CONTEXT, state)], limit)
    if not packed.fitted:
        STATS["packed_calls"] = STATS.get("packed_calls", 0) + 1
    result = _agent().predict(
        packed.text,
        questions,
        min_confidence=config.LAYA_MIN_CONFIDENCE,
        max_len=min(config.LAYA_MAX_LEN, config.CONTEXT_BUDGET),
        head_max_len=config.LAYA_HEAD_MAX_LEN,
    )
    record_usage(result, pack.count(packed.text) + question_cost(questions))
    return result.get("answers") or {}


def question_cost(questions: dict) -> int:
    """Tokens the question texts themselves occupy."""
    parts = []
    for question in questions.values():
        parts.append(str(question.get("instructions", "")))
        criteria = question.get("criteria")
        if isinstance(criteria, dict):
            parts.extend(f"{key}: {value}" for key, value in criteria.items())
        elif isinstance(criteria, list):
            parts.extend(str(item) for item in criteria)
    return pack.count("\n".join(parts))


def _batches(build, items: list, state_text: str) -> list[list[tuple[str, dict]]]:
    """Split items into groups whose questions fit alongside the state.

    A payload that is a list is never truncated: it is answered in several
    calls and the answers are merged, so every item is still decided.
    """
    limit = max(128, pack.budget() - pack.count(state_text))
    out: list[list[tuple[str, dict]]] = []
    current: list[tuple[str, dict]] = []
    used = 0
    for index, item in enumerate(items):
        key, question = build(index, item)
        cost = question_cost({key: question})
        if current and used + cost > limit:
            out.append(current)
            current, used = [], 0
        current.append((key, question))
        used += cost
    if current:
        out.append(current)
    return out


def _confidence(answer: dict) -> float:
    value = answer.get("answer_confidence")
    if value is None:
        value = answer.get("confidence")
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def classify_intent(text: str) -> tuple[str, float]:
    """Which of the three intents this request authorises."""
    STATS["intent_calls"] += 1
    answers = ask(
        text,
        {
            "intent": {
                "type": "choice",
                "instructions": "Which one best describes what the customer is asking for?",
                "criteria": INTENT_CRITERIA,
            }
        },
    )
    answer = answers.get("intent") or {}
    label = answer.get("choice") or ""
    confidence = _confidence(answer)
    if label not in INTENT_LABELS:
        STATS["intent_abstained"] += 1
        return "", confidence
    return label, confidence


def bind(subject_text: str, candidates: list[dict]) -> tuple[list[str], dict[str, float]]:
    """One yes/no question per candidate, batched to fit the context budget.

    The state is the case dossier; each candidate is a criterion the state is
    scored against, so the evidence stays in the state and the question stays a
    question. Candidates that do not fit in one call are answered in further
    calls rather than dropped.
    """

    def build(index: int, item: dict) -> tuple[str, dict]:
        return (
            f"c{index}",
            {
                "type": "noul",
                "instructions": (
                    f"Does candidate {item['resource_id']} belong to this customer? "
                    f"{item['text']}"
                ),
            },
        )

    if not candidates:
        return [], {}
    accepted: list[str] = []
    scores: dict[str, float] = {}
    for batch in _batches(build, candidates, subject_text):
        STATS["bind_calls"] += 1
        answers = ask(subject_text, dict(batch))
        for key, _ in batch:
            index = int(key[1:])
            item = candidates[index]
            probability = float((answers.get(key) or {}).get("noul") or 0.0)
            scores[item["resource_id"]] = round(probability, 4)
            if probability >= config.LAYA_BIND_THRESHOLD:
                accepted.append(item["resource_id"])
    return accepted, scores


def judge(rows: list[dict]) -> tuple[dict[str, str], str, dict[str, float]]:
    """The required state of every conditional record, plus the verdict.

    Only categories with a conditional rule are sent: unconditional deletes and
    retains are lookups against the policy table, and a probabilistic answer
    there could only subtract accuracy. The verdict is asked separately, over a
    compact summary that always fits.
    """
    conditional = [row for row in rows if row["category"] in CONDITIONAL_RULES]
    if not conditional:
        return {}, "", {}

    def build(index: int, row: dict) -> tuple[str, dict]:
        return (
            f"r{index}",
            {
                "type": "choice",
                "instructions": (
                    f"Record {row['resource_id']} in {row['system']}, data category "
                    f"{row['category']}, is currently observed as {row['observed']}. "
                    f"The supplied policy for {row['category']}: "
                    f"{CONDITIONAL_RULES[row['category']]}. What state must this "
                    f"record be in?"
                ),
                "criteria": STATE_CRITERIA,
            },
        )

    def summary(items: list[dict]) -> str:
        return "\n".join(
            f"{row['resource_id']} | {row['system']} | {row['category']} "
            f"| observed {row['observed']} | policy proposes {row['desired']}"
            for row in items
        )

    state = summary(conditional)
    decisions: dict[str, str] = {}
    confidences: dict[str, float] = {}
    for batch in _batches(build, conditional, state):
        STATS["judge_calls"] += 1
        answers = ask(state, dict(batch))
        for key, _ in batch:
            index = int(key[1:])
            row = conditional[index]
            answer = answers.get(key) or {}
            confidence = _confidence(answer)
            confidences[row["resource_id"]] = round(confidence, 4)
            choice = answer.get("choice")
            if choice in STATE_CRITERIA and confidence >= config.LAYA_JUDGE_CONFIDENCE:
                decisions[row["resource_id"]] = choice
            else:
                STATS["abstained"] += 1

    answers = ask(
        state,
        {
            "verdict": {
                "type": "choice",
                "instructions": "Is this deletion complete?",
                "criteria": VERDICT_CRITERIA,
            }
        },
    )
    verdict = (answers.get("verdict") or {}).get("choice") or ""
    return decisions, verdict if verdict in VERDICT_CRITERIA else "", confidences



MATCH_CRITERIA = {
    "MATCH": (
        "the passage concerns the customer described, because it names or refers "
        "to one of their identifiers, an email address, a phone number, an email "
        "hash, their internal reference, or their name"
    ),
    "NO_MATCH": (
        "the passage concerns a different customer, or is about something else "
        "entirely, and names none of the identifiers described"
    ),
}


def match_chunks(identifier_text: str, chunks: list[str]) -> list[tuple[bool, float]]:
    """One MATCH / NO_MATCH decision per evidence passage, in one batched pass.

    The passage is the state and the identifiers are the question, which is the
    way round a decision model is meant to be used: the evidence carries the
    content, the criterion carries what we are looking for. Passages are cut so
    that the identifier list still fits inside the same window.
    """
    if not chunks:
        return []
    STATS["match_calls"] = STATS.get("match_calls", 0) + 1
    instructions = (
        "Does this evidence passage concern the customer described? "
        "The customer's identifiers are: " + identifier_text
    )
    questions = {
        "match": {
            "type": "choice",
            "instructions": instructions,
            "criteria": MATCH_CRITERIA,
        }
    }
    # Leave room for the identifiers themselves: the passage gets the rest.
    room = pack.budget() - pack.count(instructions)
    passage_limit = max(512, min(config.EVIDENCE_MATCH_CHUNK_TOKENS, room))
    passages = [
        pack.pack([pack.Section(pack.CONTEXT, chunk)], passage_limit).text
        for chunk in chunks
    ]
    predict_kwargs = {
        "max_len": min(config.LAYA_MAX_LEN, config.CONTEXT_BUDGET),
        "head_max_len": config.EVIDENCE_MATCH_HEAD_MAX_LEN,
    }
    try:
        results = _agent().predict_batch(passages, questions, **predict_kwargs)
    except Exception:  # noqa: BLE001 - fall back to one call per passage
        results = [_agent().predict(p, questions, **predict_kwargs) for p in passages]
    out: list[tuple[bool, float]] = []
    for passage, result in zip(passages, results):
        record_usage(result, pack.count(passage) + pack.count(instructions))
        answer = ((result or {}).get("answers") or {}).get("match") or {}
        confidence = _confidence(answer)
        out.append((answer.get("choice") == "MATCH" and confidence >= config.LAYA_MIN_CONFIDENCE, confidence))
    return out


def main() -> int:
    import json
    import time

    print(f"available: {available()}  device: {config.LAYA_DEVICE}")
    print(f"checkpoint: {_checkpoint()}")
    print(f"min_confidence: {config.LAYA_MIN_CONFIDENCE}  max_len: {config.LAYA_MAX_LEN}")
    if not available():
        return 1
    start = time.time()
    label, confidence = classify_intent(_first_request())
    print(
        json.dumps(
            {
                "intent": label,
                "confidence": round(confidence, 4),
                "seconds": round(time.time() - start, 2),
            },
            indent=2,
        )
    )
    return 0


def _first_request() -> str:
    import csv

    path = config.DATASET_DIR / "sample_deletion_requests.csv"
    with path.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            if row["case_id"] == "case_02":
                return row["request_text"]
    return "Please delete my account and all personal data."


if __name__ == "__main__":
    raise SystemExit(main())
