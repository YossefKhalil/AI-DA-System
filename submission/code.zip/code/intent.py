#!/usr/bin/env python3
"""Does the request authorise deletion?

Deletion authorisation is a language question, but it is decided here by a
deterministic multilingual lexicon. The lexicon only commits when it sees an
unambiguous signal; anything it cannot read is reported as ``UNKNOWN`` and the
caller may ask the model. The label never changes the steps for a request that
does authorise deletion -- only ``NON_DELETION`` changes the output.
"""

from __future__ import annotations

import re

DELETION = "DELETION"
NON_DELETION = "NON_DELETION"
UNKNOWN = "UNKNOWN"

# Verbs that ask for data to stop existing.
_DELETION_SIGNALS = [
    r"\bdelet",
    r"\beras",
    r"\bremov",
    r"\bclos(?:e|ed|ing|ure)\b",
    r"\bpurge",
    r"\bforget\b",
    r"\belimin",
    r"\bborrar",
    r"\bsuprim",
    r"\bsuppress",
    r"\bsupprim",
    r"\beffac",
    r"\bexclu",
    r"\bapag",
    r"\bdeletar",
    r"\bl[öo]sch",
    r"\bcancellare",
    r"\bverwijder",
    r"\bta bort",
    r"\bradera",
    r"\bslet",
    r"\bpoist",
    r"\busun",
    r"削除",
    r"消去",
    r"削除",
    r"삭제",
    r"탈퇴",
    r"删除",
    r"刪除",
    r"注销",
    r"销户",
]

# Phrases that say the request is *not* about deletion, or that the account
# must survive it. These are deliberately narrow: a false NON_DELETION throws
# away a whole case, so only explicit language counts.
_NON_DELETION_SIGNALS = [
    r"not\s+(?:an?\s+)?(?:request\s+)?(?:to\s+|for\s+)?(?:delet|eras|remov|clos)",
    r"(?:do|does)\s+not\s+(?:delet|eras|remov|clos)",
    r"don'?t\s+(?:delet|eras|remov|clos)",
    r"without\s+(?:\w+\s+){0,3}?(?:delet|eras|remov|clos)",
    r"(?:keep|leave|retain)\s+(?:my|the)\s+(?:account|profile|history|records?)",
    r"account\s+(?:as it is|active|intact|open)",
    r"(?:still|continue)\s+(?:want|need|use|using)",
    r"continue\s+using",
    r"marketing\s+lists?",
    r"opt[- ]?out",
    r"unsubscribe",
]

_DELETION_RE = [re.compile(pattern, re.I) for pattern in _DELETION_SIGNALS]
_NON_DELETION_RE = [re.compile(pattern, re.I) for pattern in _NON_DELETION_SIGNALS]


def classify(text: str) -> str:
    """Return ``DELETION``, ``NON_DELETION`` or ``UNKNOWN`` for one request."""
    text = text or ""
    if any(pattern.search(text) for pattern in _NON_DELETION_RE):
        return NON_DELETION
    if any(pattern.search(text) for pattern in _DELETION_RE):
        return DELETION
    return UNKNOWN


def main() -> int:
    import csv
    from pathlib import Path

    path = Path(__file__).resolve().parents[1] / "dataset" / "deletion_requests.csv"
    counts: dict[str, int] = {}
    with path.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            label = classify(row["request_text"])
            counts[label] = counts.get(label, 0) + 1
            if label != DELETION:
                print(f"{row['case_id']} {label}: {row['request_text'][:120]}")
    print(counts)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
