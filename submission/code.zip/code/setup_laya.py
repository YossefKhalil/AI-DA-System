#!/usr/bin/env python3
"""One command to stand up the optional decision model.

    python code/setup_laya.py

That creates a dedicated environment, installs Laya and its dependencies,
downloads the multilingual checkpoint into `openwights/laya/`, and then proves
the whole thing works by asking it one real decision. When it finishes, the
audit runs with the decision model by adding a single flag:

    python code/main.py --laya

Nothing else is required, and none of this is needed at all if you only want
the deterministic audit — `python code/main.py` works with the standard library
alone.

Options:
    --env PATH        where to create the environment (default .venv-laya)
    --models PATH     where to put the checkpoint (default openwights/laya)
    --device DEVICE   cuda | cpu | mps (default: the setup picks what it sees)
    --skip-install    environment already has Laya
    --skip-download   checkpoint already present
    --check           verify an existing setup and exit
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = "convaiinnovations/laya"
CHECKPOINT = "multilingual"  # 322M params, 100+ languages, the fast one
PACKAGES = ("laya", "torch", "transformers", "pypdf")


def env_python(env: Path) -> Path:
    return env / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def run(command: list[str], **kwargs) -> int:
    print("  $", " ".join(str(part) for part in command), flush=True)
    return subprocess.call(command, **kwargs)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--env", default=str(ROOT / ".venv-laya"))
    parser.add_argument("--models", default=str(ROOT / "openwights" / "laya"))
    parser.add_argument("--device", default=os.environ.get("LAYA_DEVICE", "cuda"))
    parser.add_argument("--skip-install", action="store_true")
    parser.add_argument("--skip-download", action="store_true")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args(argv)

    env = Path(args.env).expanduser().resolve()
    models = Path(args.models).expanduser().resolve()
    python = env_python(env)
    checkpoint = models / CHECKPOINT

    print("Laya setup")
    print(f"  environment {env}")
    print(f"  checkpoint  {checkpoint}")

    if not args.check:
        if not python.is_file():
            print("\n[1/4] creating the environment")
            run([sys.executable, "-m", "venv", str(env)])
        else:
            print("\n[1/4] environment already exists")

        if not args.skip_install:
            print("\n[2/4] installing Laya and its dependencies")
            run([str(python), "-m", "pip", "install", "--quiet", "--upgrade", "pip"])
            if run([str(python), "-m", "pip", "install", "--quiet", *PACKAGES]) != 0:
                print("installation failed", file=sys.stderr)
                return 1
        else:
            print("\n[2/4] install skipped")

        if not args.skip_download and not (checkpoint / "model.safetensors").is_file():
            print("\n[3/4] downloading the checkpoint (about 615 MB, once)")
            code = (
                "from huggingface_hub import snapshot_download;"
                f"snapshot_download({REPO!r}, revision='main', local_dir={str(models)!r},"
                f" allow_patterns=[{CHECKPOINT + '/*'!r}])"
            )
            if run([str(python), "-c", code]) != 0:
                print("download failed; re-run this script to resume", file=sys.stderr)
                return 1
        else:
            print("\n[3/4] checkpoint already present")

    print("\n[4/4] verifying with a real decision")
    environment = dict(os.environ)
    environment["PYTHONPATH"] = str(ROOT / "code")
    environment["LAYA_DIR"] = str(models)
    environment["LAYA_DEVICE"] = args.device
    environment["HF_HUB_OFFLINE"] = "1"
    environment["TRANSFORMERS_OFFLINE"] = "1"
    status = run([str(python), str(ROOT / "code" / "laya_engine.py")], env=environment)
    if status != 0:
        print("\nverification failed. If the checkpoint is incomplete, re-run without", file=sys.stderr)
        print("--skip-download; if the device is wrong, try --device cpu", file=sys.stderr)
        return 1

    print("\nReady. Run the audit with the decision model:")
    print("  python code/main.py --laya")
    print("and without it (the deterministic path, no dependencies):")
    print("  python code/main.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
