#!/usr/bin/env python3
"""Observed state.

Given the records that belong to one resource, decide what state that
resource was actually in at the case's audit time, and which piece of
evidence proves it.

Two different kinds of claim live here. A *lookup* record says something
about one resource ("this profile returned 404"). A *capture* says something
about a whole store ("this snapshot of account_service contains these rows"),
and a capture is the only thing that can prove a resource is absent, because
absence is a statement about the capture's scope rather than about the
resource.
"""

from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

try:
    from . import config, policy
except ImportError:  # running as a plain script
    import config
    import policy

try:
    from . import evidence
except ImportError:
    import evidence

ABSENT_STATES = {"NOT_FOUND", "MISSING", "DELETED", "ABSENT", "REMOVED", "PURGED"}
# Which store a capture's tables describe. A capture that holds
# ``customer_profiles`` was taken from the account service, so it can prove
# an account id absent.
TABLE_SYSTEM = {
    "customer_profiles": "account_service",
    "customer_profiles_primary": "account_service",
    "customer_profiles_failover_replica": "account_service",
    "customer_accounts": "account_service",
    "customer_search_documents": "search_service",
    "search_documents_primary": "search_service",
    "customer_analytics_profiles": "analytics_platform",
    "support_records": "support_platform",
    "customer_exports": "export_service",
    "connector_subscriptions": "integration_service",
    "backup_restore_entries": "backup_service",
    "security_audit_records": "security_service",
}

# Attribute names that, when populated, mean the record still names somebody.
# Identifiers that name the person directly. A stable internal reference such
# as ``user_541`` is excluded: a tombstone is *supposed* to keep that one.
DIRECT_FIELDS = (
    "email",
    "customer_email",
    "owner_email",
    "requester_email",
    "email_hash",
    "phone",
    "requester_phone",
    "owner_phone",
    "full_name",
    "display_name",
    "requester_name",
)

# Fields whose presence means the record is a conversation rather than a
# point lookup, which is what makes a support record retainable context.
CONVERSATION_FIELDS = (
    "message_text",
    "message_excerpt",
    "message",
    "body",
    "conversation",
    "transcript",
)

# A record that states its own state is the best evidence we have about it.
STATED_STATES = {
    "ACTIVE": "ACTIVE",
    "DISABLED": "DISABLED",
    "BLOCKED": "BLOCKED",
    "REDACTED": "REDACTED",
    "ANONYMIZED": "ANONYMIZED",
    "FOUND": "PRESENT",
    "PRESENT": "PRESENT",
    "IDENTIFIABLE": "PRESENT",
    "EXISTS": "PRESENT",
}

ABSENT_CODES = {"404"}

# How many records each evidence file contributed. A file that holds few
# records is a more targeted statement about any one of them.
_FILE_WEIGHT: dict[str, int] = {}


def set_file_weights(records: list[evidence.Record]) -> None:
    """Record how broad each evidence file is, for evidence selection."""
    counts: dict[str, int] = {}
    for record in records:
        if record.file_id:
            counts[record.file_id] = counts.get(record.file_id, 0) + 1
    _FILE_WEIGHT.clear()
    _FILE_WEIGHT.update(counts)


def parse_time(value: str) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).astimezone(
            timezone.utc
        )
    except ValueError:
        return None


@dataclass
class Capture:
    """A snapshot that asserts what a whole store held, and when."""

    file_id: str
    captured_at: str
    systems: set[str] = field(default_factory=set)
    resource_ids: set[str] = field(default_factory=set)


@dataclass
class Observation:
    """What one resource was, what it must be, and what proves it."""

    resource_id: str
    system: str
    category: str
    observed: str
    desired: str
    evidence_id: str = ""
    tier: str = ""


def load_captures() -> list[Capture]:
    """Every SQL capture, with the systems and rows it covers."""
    captures: list[Capture] = []
    for row in evidence.manifest():
        path = config.DATASET_DIR / row["file_path"]
        if path.suffix.lower() != ".sql":
            continue
        payload = _read_capture(path)
        if payload is None:
            continue
        systems, ids = payload
        captures.append(
            Capture(
                file_id=row["file_id"],
                captured_at=row.get("captured_at", ""),
                systems=systems,
                resource_ids=ids,
            )
        )
    return captures


def _read_capture(path: Path) -> tuple[set[str], set[str]] | None:
    connection = sqlite3.connect(":memory:")
    try:
        connection.executescript(path.read_text(encoding="utf-8", errors="ignore"))
        tables = [
            name
            for (name,) in connection.execute(
                "select name from sqlite_master where type='table'"
            )
        ]
        systems: set[str] = set()
        table_systems: set[str] = set()
        ids: set[str] = set()
        for table in tables:
            columns = [
                info[1]
                for info in connection.execute(f"pragma table_info('{table}')")
            ]
            if table == "snapshot_scope":
                if "origin_system" in columns:
                    index = columns.index("origin_system")
                    for row in connection.execute(f"select * from '{table}'"):
                        value = row[index]
                        if isinstance(value, str) and value.strip():
                            systems.add(value.strip().lower())
                continue
            system = TABLE_SYSTEM.get(table)
            if system:
                table_systems.add(system)
            if "resource_id" not in columns:
                continue
            for (value,) in connection.execute(
                f"select resource_id from '{table}'"
            ):
                if value:
                    ids.add(str(value))
        # A declared scope is authoritative. With no declaration, coverage is
        # inferred from the tables the capture holds, and failing that from the
        # id prefixes it actually contains: a dump that demonstrably holds
        # account rows replicates the account store, so a missing account id in
        # it does mean that account is gone. Absence by omission is sound in the
        # one direction that matters; presence may lag.
        prefix_systems = {
            evidence.system_for(resource_id) for resource_id in ids
        } - {"", "unknown"}
        return (systems or table_systems or prefix_systems), ids
    except sqlite3.Error:
        return None
    finally:
        connection.close()


def _field(record: evidence.Record, name: str) -> str:
    value = record.attributes.get(name)
    if value is None:
        return ""
    return str(value).strip()


def facts_for(records: list[evidence.Record], subject) -> policy.Facts:
    """Summarise a resource's records in the terms the policy asks about."""
    facts = policy.Facts()
    for record in records:
        for value in record.identifiers:
            text = str(value).strip().lower()
            if not text:
                continue
            if subject is None or subject.matches_tokens([value]):
                facts.identifiers.add(text)
        for name in DIRECT_FIELDS:
            value = _field(record, name)
            if value:
                facts.direct.add(value.lower())
        if any(_field(record, name) for name in CONVERSATION_FIELDS):
            facts.conversation = True
        event = _field(record, "event").lower()
        if not event or "restore" in event:
            # A restore candidate that is eligible and not blocked can bring
            # the data back.
            if _field(record, "eligible").lower() in {"1", "true", "yes"}:
                facts.restore_allowed = True
            if _field(record, "deletion_block").lower() in {"0", "false", "no"}:
                facts.restore_allowed = True
        for name in ("restore_allowed",):
            value = _field(record, name).lower()
            if value in {"1", "true", "yes"}:
                facts.restore_allowed = True
        for name in ("enabled", "is_enabled"):
            value = _field(record, name).lower()
            if value in {"1", "true", "yes"}:
                facts.enabled = True
        if _field(record, "retention_until"):
            facts.retain_until = _field(record, "retention_until")
    return facts


def _other_parties(records: list[evidence.Record], subject) -> int:
    """Count identifiers in these records that are not the subject's."""
    others: set[str] = set()
    for record in records:
        for value in record.identifiers:
            text = str(value).strip()
            if not text:
                continue
            if subject is not None and subject.matches_tokens([text]):
                continue
            others.add(text.lower())
    return len(others)


def observed_state(
    resource_id: str,
    system: str,
    records: list[evidence.Record],
    subject,
    captures: list[Capture],
    audit_at: str,
) -> Observation:
    category = policy.category_of(resource_id, _stated_category(records))
    facts = facts_for(records, subject)
    facts.other_parties = _other_parties(records, subject)
    desired = policy.desired_state(category, facts)

    found = bool(records)
    explicit_absent = any(
        _field(record, "state").upper() in ABSENT_STATES
        or _field(record, "result").upper() in ABSENT_STATES
        or _field(record, "status").upper() in ABSENT_STATES
        for record in records
    )
    # A lookup that returned nothing is a statement about that one resource.
    if _lookup_absent(records) or explicit_absent and not any(
        _field(record, name)
        for record in records
        for name in DIRECT_FIELDS
    ):
        found = False

    evidence_id = ""
    if found:
        observed = _state_when_found(category, facts, _stated_state(records))
        evidence_id = _pick_evidence(records, present=True)
    else:
        observed = "ABSENT"
        if desired == "BLOCKED":
            observed = "BLOCKED"
        elif desired == "ANONYMIZED":
            observed = "ANONYMIZED"
        evidence_id = _pick_evidence(records, present=False) or _absence_evidence(
            resource_id, system, captures, audit_at, records
        )
    return Observation(
        resource_id=resource_id,
        system=system,
        category=category,
        observed=observed,
        desired=desired,
        evidence_id=evidence_id,
    )


def _stated_category(records: list[evidence.Record]) -> str:
    # A contact record that tracks an email opt-in is marketing data, whatever
    # store it happens to live in.
    if any(_field(record, "email_opt_in") for record in records):
        return "MARKETING_PROFILE"
    # A copy held in a legacy lookup index is a secondary identifier, not the
    # primary record it mirrors.
    if any("legacy" in _field(record, "source").lower() for record in records):
        return "SECONDARY_IDENTIFIER"
    for record in records:
        if record.record_type:
            return record.record_type
    return ""


def _lookup_absent(records: list[evidence.Record]) -> bool:
    """A point lookup that came back empty says the record is not there.

    ``rows=0`` or a 404 from the owning system is direct evidence about that
    one resource, unlike silence in a snapshot.
    """
    for record in records:
        for name in ("status_code", "http_status"):
            if _field(record, name) in ABSENT_CODES:
                return True
        if _field(record, "rows") == "0":
            return True
    return False


def _stated_state(records: list[evidence.Record]) -> str:
    """The first state a record states for itself, in our vocabulary."""
    for record in records:
        for name in ("state", "result"):
            value = _field(record, name).upper()
            if value in STATED_STATES:
                return STATED_STATES[value]
    return ""


def _state_when_found(category: str, facts: policy.Facts, stated: str = "") -> str:
    """The observed state of a resource whose record is present."""
    if stated and stated != "PRESENT":
        return stated
    if category == "DATA_FLOW":
        return "ACTIVE" if facts.enabled else "DISABLED"
    if category == "BACKUP_ARCHIVE":
        return "ACTIVE" if facts.restore_allowed else "BLOCKED"
    if category in {"ANALYTICS_PROFILE", "PRODUCT_TELEMETRY"}:
        return "PRESENT" if facts.attributable else "ANONYMIZED"
    if category == "ACCOUNT_TOMBSTONE":
        return "PRESENT" if facts.identifiable else "REDACTED"
    if category in {"SUPPORT_MESSAGE", "EMAIL_DELIVERY_LOG"}:
        return "PRESENT" if facts.identifiable else "REDACTED"
    return "PRESENT"


def _pick_evidence(records: list[evidence.Record], present: bool) -> str:
    """The single file that best proves this observation.

    Preference order: the most targeted source (a file that holds few records
    says more about this one than a broad export does), then the most recent
    capture at or before the audit, then the evidence id.
    """
    del present
    ranked = sorted(records, key=lambda record: record.file_id, reverse=True)
    ranked.sort(key=lambda record: record.captured_at or "", reverse=True)
    ranked.sort(key=lambda record: _FILE_WEIGHT.get(record.file_id, 0))
    return ranked[0].file_id if ranked else ""


def _absence_evidence(
    resource_id: str,
    system: str,
    captures: list[Capture],
    audit_at: str,
    records: list[evidence.Record],
) -> str:
    """The capture that proves this resource was not there.

    Prefer a capture of the resource's own store taken at or before the audit
    time. Fall back to whatever record told us the lookup failed.
    """
    cutoff = parse_time(audit_at)
    usable = [
        capture
        for capture in captures
        if system in capture.systems
        and resource_id not in capture.resource_ids
        and (cutoff is None or (parse_time(capture.captured_at) or cutoff) <= cutoff)
    ]
    if usable:
        # The most specific capture wins: an account-only replica capture
        # proves more about the account store than a whole-platform
        # inventory does. Ties go to the most recent capture.
        usable.sort(key=lambda c: c.captured_at or "", reverse=True)
        usable.sort(key=lambda c: len(c.systems))
        return usable[0].file_id
    if records:
        return _pick_evidence(records, present=False)
    return ""


def main() -> int:
    captures = load_captures()
    print(f"captures: {len(captures)}")
    for capture in sorted(captures, key=lambda c: c.captured_at):
        print(
            f"  {capture.file_id} {capture.captured_at} "
            f"systems={sorted(capture.systems)} rows={len(capture.resource_ids)}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
