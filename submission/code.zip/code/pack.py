#!/usr/bin/env python3
"""Context packing: nothing reaches the decision model above its budget.

Every payload the decision model sees is assembled from **named sections**, in
priority order, and measured with the model's own tokenizer. If the payload
does not fit, the packer drops the lowest-priority sections first, truncates at
a line boundary with a visible marker, and reports what it dropped. A payload
that is a long *list* (candidate records, in-scope records) is split into
groups that each fit, so the caller can make one call per group and merge.

Why this exists: the decision model's encoder has a hard positional limit
(`max_position_embeddings: 8192`). The largest evidence file is ~74k tokens, so
raw evidence can never be handed over; and the largest assembled payload
measured 7,211 tokens, close enough to the ceiling that a busier case would
have overflowed silently.

Sections are the organising idea: the caller declares what each part is and how
important it is, and the packer decides what survives.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from functools import lru_cache

try:
    from . import config
except ImportError:  # running as a plain script
    import config

# Section names used across the pipeline. Higher priority survives a squeeze.
CASE = "CASE"
IDENTIFIERS = "IDENTIFIERS"
RECORDS = "RECORDS"
CANDIDATES = "CANDIDATES"
CONTEXT = "CONTEXT"
NOTES = "NOTES"

PRIORITY = {
    CASE: 100,
    IDENTIFIERS: 90,
    RECORDS: 80,
    CANDIDATES: 70,
    CONTEXT: 40,
    NOTES: 10,
}

TRUNCATION_MARKER = "\n[... truncated to fit the model's context ...]"


@lru_cache(maxsize=1)
def _tokenizer():
    """The decision model's tokenizer when it can be loaded, else None.

    A character estimate is only ever a fallback; the real count is used
    whenever the checkpoint is present.
    """
    try:
        from transformers import AutoTokenizer
    except Exception:  # noqa: BLE001 - no tokenizer available in this seat
        return None
    for path in config.LAYA_MODELS.values():
        if not (path / "model.safetensors").is_file():
            continue
        for candidate in (path / "tokenizer", path):
            if (candidate / "tokenizer.json").is_file():
                try:
                    return AutoTokenizer.from_pretrained(str(candidate))
                except Exception:  # noqa: BLE001
                    return None
    return None


def count(text: str) -> int:
    """Tokens in ``text``. Conservative when the tokenizer is unavailable."""
    if not text:
        return 0
    tokenizer = _tokenizer()
    if tokenizer is None:
        # Deliberately pessimistic: three characters per token overestimates
        # for prose, so a budget check errs on the safe side.
        return len(text) // 3 + 1
    return len(tokenizer.encode(text, add_special_tokens=False))


def budget() -> int:
    """How many tokens one payload may occupy."""
    return max(256, int(config.CONTEXT_BUDGET) - int(config.CONTEXT_RESERVE))


@dataclass
class Section:
    name: str
    text: str = ""
    lines: list[str] = field(default_factory=list)

    @property
    def body(self) -> str:
        return self.text or "\n".join(self.lines)


@dataclass
class Packed:
    """The result of a pack: what to send, and what was given up."""

    text: str
    dropped: list[str] = field(default_factory=list)
    truncated: list[str] = field(default_factory=list)

    @property
    def fitted(self) -> bool:
        return not self.dropped and not self.truncated


def render(sections: list[Section]) -> str:
    """Format sections with their labels so the model can tell them apart."""
    blocks = []
    for section in sections:
        body = section.body.strip()
        if body:
            blocks.append(f"### {section.name}\n{body}")
    return "\n\n".join(blocks)


def pack(sections: list[Section], limit: int | None = None) -> Packed:
    """Fit named sections into ``limit`` tokens, dropping the least important.

    A section that does not fit on its own is truncated at a line boundary
    rather than dropped mid-line, and the truncation is marked in the text so
    nothing is silently concealed from the reader.
    """
    limit = limit if limit is not None else budget()
    ordered = sorted(sections, key=lambda s: -PRIORITY.get(s.name, 0))

    kept: list[Section] = []
    dropped: list[str] = []
    truncated: list[str] = []

    for section in ordered:
        body = section.body.strip()
        if not body:
            continue
        candidate = render(kept + [section])
        if count(candidate) <= limit:
            kept.append(section)
            continue
        # Try to keep part of it: one line is the smallest useful unit.
        if isinstance(section, Section) and section.lines:
            kept
            room = limit - count(render(kept)) - count(f"### {section.name}\n")
            trimmed: list[str] = []
            for line in section.lines:
                if room - count(line) - 1 < 0:
                    break
                trimmed.append(line)
                room -= count(line) + 1
            if trimmed:
                kept.append(Section(section.name, "\n".join(trimmed) + TRUNCATION_MARKER))
                truncated.append(section.name)
                continue
        dropped.append(section.name)

    return Packed(text=render(kept), dropped=dropped, truncated=truncated)


def groups(lines: list[str], limit: int | None = None) -> list[list[str]]:
    """Split a long list of lines into groups that each fit ``limit``.

    Used where the payload is a list rather than prose: candidate records, or
    the in-scope records of one case. The caller makes one model call per group
    and merges the answers, so nothing is dropped and nothing overflows.
    """
    limit = limit if limit is not None else budget()
    out: list[list[str]] = []
    current: list[str] = []
    used = 0
    for line in lines:
        cost = count(line) + 1
        if current and used + cost > limit:
            out.append(current)
            current, used = [], 0
        current.append(line)
        used += cost
    if current:
        out.append(current)
    return out


def chunk(text: str, limit: int | None = None) -> list[str]:
    """Cut one long text into ordered pieces that each fit ``limit``.

    For the perception seat: a multi-thousand-token document is read in order,
    in pieces, instead of being truncated to the first window.
    """
    return ["\n".join(group) for group in groups(text.splitlines(), limit)]


def main() -> int:
    print(f"budget: {budget()} tokens (CONTEXT_BUDGET={config.CONTEXT_BUDGET}, "
          f"reserve={config.CONTEXT_RESERVE})")
    print(f"tokenizer: {'laya' if _tokenizer() is not None else 'character estimate'}")
    sample = [Section(CANDIDATES, "\n".join(f"candidate c{i} in system_s {i}" for i in range(400)))]
    packed = pack(sample)
    print(f"one 400-line section -> {count(packed.text)} tokens, "
          f"truncated={packed.truncated} dropped={packed.dropped}")
    print(f"groups: {len(groups(sample[0].lines))} pieces, "
          f"largest {max(count(g) for g in groups(sample[0].lines))} tokens")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
