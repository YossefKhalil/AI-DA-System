#!/usr/bin/env python3
"""Paths and settings. Every value is overridable from the environment.

Nothing here knows anything about the audit domain; it only answers
"where are the files" and "how do we reach the model".
"""

from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _path(env: str, default: Path) -> Path:
    raw = os.environ.get(env)
    return Path(raw).expanduser().resolve() if raw else default


DATASET_DIR = _path("DATASET_DIR", ROOT / "dataset")
OUTPUT_CSV = _path("OUTPUT_CSV", ROOT / "output.csv")
CACHE_DIR = _path("CACHE_DIR", ROOT / ".cache")
EVALUATION_DIR = _path("EVALUATION_DIR", ROOT / "evaluation")

# OpenAI-compatible endpoint. Defaults target a local llama.cpp server.
BASE_URL = os.environ.get("OPENAI_BASE_URL", "http://localhost:8080/v1").rstrip("/")
API_KEY = os.environ.get("OPENAI_API_KEY", "none")
MODEL = os.environ.get("OPENAI_MODEL", "")
TIMEOUT = float(os.environ.get("OPENAI_TIMEOUT", "900"))

# Generation budgets. A CPU-bound server runs at a few tokens per second, so
# these stay deliberately small; raise them only when accuracy demands it.
INTENT_MAX_TOKENS = int(os.environ.get("INTENT_MAX_TOKENS", "256"))
VISION_MAX_TOKENS = int(os.environ.get("VISION_MAX_TOKENS", "768"))
BIND_MAX_TOKENS = int(os.environ.get("BIND_MAX_TOKENS", "1024"))
JUDGE_MAX_TOKENS = int(os.environ.get("JUDGE_MAX_TOKENS", "2048"))

# Laya decision engine. The checkpoints live outside the dataset; set these to
# a local directory to keep the engine fully offline.
LAYA_DIR = _path("LAYA_DIR", ROOT / "openwights" / "laya")
# Where `code/setup_laya.py` installs the decision model's environment.
LAYA_ENV = _path("LAYA_ENV", ROOT / ".venv-laya")
LAYA_MODELS = {
    "english": _path("LAYA_ENGLISH", LAYA_DIR),
    "multilingual": _path("LAYA_MULTILINGUAL", LAYA_DIR / "multilingual"),
    "typed-decisions": _path("LAYA_TYPED", LAYA_DIR / "typed-decisions"),
}
LAYA_DEVICE = os.environ.get("LAYA_DEVICE", "cuda")
# How sure a decision has to be before it replaces the deterministic answer.
LAYA_MIN_CONFIDENCE = float(os.environ.get("LAYA_MIN_CONFIDENCE", "0.50"))
# Token budget for the decision model's input. The checkpoint's encoder stops at
# 8192; measuring our own payloads showed 8.7 percent of cases were truncated at
# 1024 and 3.7 percent at 2048, so the budget is the full window.
LAYA_MAX_LEN = int(os.environ.get("LAYA_MAX_LEN", "8192"))
# Budget for the question and option text. The model's own guidance is that the
# wording of each option is what makes a decision accurate, and our treatment
# question carries six options plus the policy rule, so this is wider than the
# checkpoint's 256 default.
LAYA_HEAD_MAX_LEN = int(os.environ.get("LAYA_HEAD_MAX_LEN", "384"))
# Binding is an exclusion, not an admission: a candidate has to beat the
# runner-up in its own system by a margin before it is accepted.
LAYA_BIND_THRESHOLD = float(os.environ.get("LAYA_BIND_THRESHOLD", "0.75"))
LAYA_BIND_MARGIN = float(os.environ.get("LAYA_BIND_MARGIN", "0.15"))
# The treatment question is only asked about categories whose rule is
# conditional. Unconditional deletes and retains are lookups, not decisions.
LAYA_JUDGE_CONFIDENCE = float(os.environ.get("LAYA_JUDGE_CONFIDENCE", "0.70"))
# Reading a deletion request as "not a deletion" empties the whole case.
LAYA_NON_DELETION_CONFIDENCE = float(os.environ.get("LAYA_NON_DELETION_CONFIDENCE", "0.90"))

# Context packing. The encoder's positional limit is 8192, so no payload may
# exceed that; the reserve covers the question text and special tokens.
CONTEXT_BUDGET = int(os.environ.get("CONTEXT_BUDGET", "8192"))
CONTEXT_RESERVE = int(os.environ.get("CONTEXT_RESERVE", "256"))

# Where binding candidates come from. "file" only offers records that share a
# file with the case's other records; "window" offers every unclaimed record in
# the case's time window for systems the case does not already cover.
CANDIDATE_POOL = os.environ.get("CANDIDATE_POOL", "window")
CANDIDATE_CAP = int(os.environ.get("CANDIDATE_CAP", "6"))
BIND_MAX_PER_CASE = int(os.environ.get("BIND_MAX_PER_CASE", "99"))

# The deterministic lexicon as a guard over the model's intent answer. The
# lexicon reads explicit signals ("not asking for deletion", "do not close")
# that a probabilistic answer should not override. Off means the model's answer
# stands unconditionally.
LEXICON_GUARD = os.environ.get("LEXICON_GUARD", "1") not in {"0", "false", "no"}

# File-by-file reading by the decision model: chunks of evidence that the
# parser did not bind are offered to the model, which judges whether they
# concern the subject. Code verifies every resource id that follows.
EVIDENCE_SCAN = os.environ.get("EVIDENCE_SCAN", "1") not in {"0", "false", "no"}
# Evidence matching: each passage of evidence is the STATE, the case's
# identifiers are the QUESTION, and the answer is MATCH / NO_MATCH. Passages are
# cut to ~7k tokens so the identifier list still fits in the same window.
EVIDENCE_MATCH = os.environ.get("EVIDENCE_MATCH", "0") not in {"0", "false", "no"}
EVIDENCE_MATCH_CHUNK_TOKENS = int(os.environ.get("EVIDENCE_MATCH_CHUNK_TOKENS", "7000"))
EVIDENCE_MATCH_MAX_CHUNKS = int( os.environ.get("EVIDENCE_MATCH_MAX_CHUNKS", "0"))  # 0 = every passage
EVIDENCE_MATCH_HEAD_MAX_LEN = int(
    os.environ.get("EVIDENCE_MATCH_HEAD_MAX_LEN", str(LAYA_HEAD_MAX_LEN))
)
# How many candidate records the decision model is shown per system. This is
# the knob that controls binding quality: too many near-identical rows and the
# model has nothing to discriminate on.
CANDIDATE_CAP = int(os.environ.get("CANDIDATE_CAP", "10"))
# Ceiling on how many bindings the decision model may add to one case.
BIND_MAX_PER_CASE = int(os.environ.get("BIND_MAX_PER_CASE", "99"))
