#!/usr/bin/env python3
"""Typed model tasks. Prompts and schemas live here, transport in llm.py.

Two tasks only, both narrow and both verifiable:

    intent   three-way classification of a request in any language
    vision   transcription of identifiers/states out of a screenshot

Neither task decides a case. The pipeline is deterministic; these tasks
supply an input the code cannot read by itself.

CLI:
    python code/model_tasks.py intent "Bitte loeschen Sie mein Konto."
    python code/model_tasks.py image dataset/evidence/images/<name>.png
    python code/model_tasks.py images
"""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path
from typing import Iterable

try:
    from . import config
    from .llm import Reply, chat, image_part
except ImportError:  # pragma: no cover - direct script execution
    import config  # type: ignore
    from llm import Reply, chat, image_part  # type: ignore


# ----------------------------------------------------------------- intent --

INTENT_LABELS = ("DELETE", "VERIFY_DELETION", "NON_DELETION")

INTENT_SCHEMA = {
    "type": "object",
    "properties": {
        "intent": {"type": "string", "enum": list(INTENT_LABELS)},
        "confidence": {"type": "number"},
        "language": {"type": "string"},
        "reason": {"type": "string"},
    },
    "required": ["intent", "confidence", "language", "reason"],
    "additionalProperties": False,
}

INTENT_SYSTEM = """You classify one message a customer sent to a commerce platform's privacy team.

DELETE
  The person asks for their account or personal data to be erased, closed,
  removed, or no longer kept.

VERIFY_DELETION
  The person asks whether an earlier deletion is finished, or asks for an
  unfinished deletion to be completed. They still want the data gone.

NON_DELETION
  Anything else. This includes reading or copying their data, correcting a
  field, stopping marketing email, help signing in, or a general question.
  A request that keeps the account is NON_DELETION even if it mentions
  removing something.

Weigh what the person wants to happen, not which words they used. The message
may be in any language. Answer with JSON only."""


def classify_intent(request_text: str) -> Reply:
    """Return the three-way intent for a request body."""
    return chat(
        [
            {"role": "system", "content": INTENT_SYSTEM},
            {"role": "user", "content": request_text},
        ],
        task="intent",
        schema=INTENT_SCHEMA,
        max_tokens=config.INTENT_MAX_TOKENS,
    )


# ----------------------------------------------------------------- vision --

VISION_SCHEMA = {
    "type": "object",
    "properties": {
        "system": {"type": "string"},
        "resource_ids": {"type": "array", "items": {"type": "string"}},
        "identifiers": {"type": "array", "items": {"type": "string"}},
        "records": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "resource_id": {"type": "string"},
                    "record_type": {"type": "string"},
                    "state": {"type": "string"},
                    "identifier": {"type": "string"},
                },
                "required": ["resource_id", "record_type", "state", "identifier"],
                "additionalProperties": False,
            },
        },
        "visible_text": {"type": "string"},
    },
    "required": ["system", "resource_ids", "identifiers", "records", "visible_text"],
    "additionalProperties": False,
}

VISION_SYSTEM = """You transcribe an internal operations screenshot.

Copy identifiers, emails, phone numbers, names, statuses and record states
exactly as they appear, character for character. Never complete, correct or
guess a value. If a field is blank, truncated or hidden, return an empty
string for it. If you cannot read an identifier, leave it out rather than
approximating it.

Set "visible_text" to the raw text you can read, in reading order.
Answer with JSON only."""

VISION_PROMPT = (
    "Transcribe this screenshot. List every resource identifier, record type, "
    "state and identifier you can read."
)


def extract_image(path: Path, focus: str = "") -> Reply:
    """Transcribe one screenshot into structured identifiers and records."""
    prompt = VISION_PROMPT + (f" Pay particular attention to: {focus}." if focus else "")
    return chat(
        [
            {"role": "system", "content": VISION_SYSTEM},
            {
                "role": "user",
                "content": [{"type": "text", "text": prompt}, image_part(path)],
            },
        ],
        task="vision",
        schema=VISION_SCHEMA,
        max_tokens=config.VISION_MAX_TOKENS,
    )


# ------------------------------------------------------------ manifest io --

IMAGE_SUFFIXES = (".png", ".jpg", ".jpeg", ".webp", ".gif")


def manifest_images() -> list[tuple[str, Path]]:
    """(file_id, absolute path) for every image in the evidence manifest."""
    manifest = config.DATASET_DIR / "evidence_files.csv"
    found: list[tuple[str, Path]] = []
    with manifest.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            relative = (row.get("file_path") or "").strip()
            if not relative:
                continue
            if Path(relative).suffix.lower() in IMAGE_SUFFIXES:
                found.append((row["file_id"], (config.DATASET_DIR / relative).resolve()))
    return found


def extract_all_images(out_path: Path | None = None) -> Path:
    """Transcribe every image in the manifest. Results are cached on disk."""
    target = out_path or (config.CACHE_DIR / "vision" / "extracts.json")
    results: dict[str, dict] = {}
    if target.is_file():
        results = json.loads(target.read_text(encoding="utf-8"))
    for file_id, path in manifest_images():
        if file_id in results and results[file_id].get("ok"):
            continue
        try:
            reply = extract_image(path)
            results[file_id] = {
                "ok": True,
                "file_path": str(path.relative_to(config.DATASET_DIR)).replace("\\", "/"),
                "cached": reply.cached,
                "json": reply.json,
                "text": reply.text,
            }
        except Exception as exc:  # noqa: BLE001 - record and continue
            results[file_id] = {"ok": False, "error": str(exc)}
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"{file_id}: {'ok' if results[file_id]['ok'] else results[file_id]['error']}", flush=True)
    return target


# -------------------------------------------------------------------- cli --

def main(argv: Iterable[str]) -> int:
    argv = list(argv)
    if not argv:
        print(__doc__)
        return 0

    command = argv[0]

    if command == "intent":
        reply = classify_intent(" ".join(argv[1:]))
        print(json.dumps(reply.json, indent=2, ensure_ascii=False))
        return 0

    if command == "image":
        reply = extract_image(Path(argv[1]), " ".join(argv[2:]))
        print(json.dumps(reply.json, indent=2, ensure_ascii=False))
        print(f"cached={reply.cached} usage={reply.usage}")
        return 0

    if command == "images":
        print(extract_all_images())
        return 0

    print(f"unknown command: {command}", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
