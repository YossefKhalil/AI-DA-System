#!/usr/bin/env python3
"""How much context does the evidence actually demand?

Two different questions, measured separately because they have different
answers:

  per file   how many tokens is each evidence file on its own? (the question
             "does any single piece of evidence exceed the window?")
  per case   how many tokens does the decision model actually receive for one
             case, once the pipeline has assembled it?

Token counts use the decision model's own tokenizer, not a character estimate.

Run:
    python -X utf8 code/measure_context.py
"""

from __future__ import annotations

import csv
from pathlib import Path

try:
    from . import config, evidence, main, observe, resolve
except ImportError:  # running as a plain script
    import config
    import evidence
    import main
    import observe
    import resolve

WINDOWS = (512, 1024, 2048, 8192)


def load_tokenizer():
    """The decision model's tokenizer, straight from the checkpoint."""
    from transformers import AutoTokenizer

    root = None
    for path in config.LAYA_MODELS.values():
        if (path / "model.safetensors").is_file():
            root = path
            break
    if root is None:
        raise RuntimeError("no local checkpoint")
    for candidate in (root / "tokenizer", root):
        if (candidate / "tokenizer.json").is_file():
            return AutoTokenizer.from_pretrained(str(candidate))
    raise RuntimeError(f"no tokenizer.json under {root}")


def count(tokenizer, text: str) -> int:
    return len(tokenizer.encode(text, add_special_tokens=False))


def per_file(tokenizer) -> list[tuple[str, int, int]]:
    """(file_id, tokens, bytes) for every file in the manifest."""
    rows = []
    for row in evidence.manifest():
        path = config.DATASET_DIR / row["file_path"]
        if not path.is_file():
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        rows.append((row["file_id"], count(tokenizer, text), path.stat().st_size))
    return rows


def per_case(tokenizer, cases, records, captures) -> list[tuple[str, int, int, int]]:
    """(case_id, intent_tokens, bind_tokens, judge_tokens) for each case.

    Measures what the model is really handed: the state text plus the question
    text, exactly as `code/laya_engine.py` builds them.
    """
    binder = resolve.Binder(records, identity_directory(), captures)
    bound = binder.bind(cases)
    claimed = {item.resource_id for items in bound.values() for item in items}
    out = []
    for case in cases:
        if case.subject is None:
            intent_tokens = count(tokenizer, case.request_text)
        else:
            intent_tokens = count(tokenizer, case.request_text)
        items = bound.get(case.case_id, [])
        candidates = main._candidates(case, items, binder, claimed)
        flat = [item for bucket in candidates.values() for item in bucket]
        bind_tokens = count(tokenizer, main._subject_text(case)) + sum(
            count(tokenizer, f"Does candidate {item['resource_id']} belong to this customer? {item['text']}")
            for item in flat
        )
        observations = [
            observe.observed_state(
                item.resource_id, item.system, item.records, case.subject, captures, case.audit_at
            )
            for item in items
        ]
        state = "\n".join(
            f"{obs.resource_id} | {obs.system} | {obs.category or 'unstated'} | observed "
            f"{obs.observed} | policy proposes {obs.desired}"
            for obs in observations
        )
        judge_tokens = count(tokenizer, state)
        out.append((case.case_id, intent_tokens, bind_tokens, judge_tokens))
    return out


def identity_directory():
    import identity

    return identity.Directory()


def report(label: str, values: list[int]) -> None:
    values = sorted(values, reverse=True)
    print(f"\n{label}: n={len(values)}  max={values[0]:,}  median={values[len(values)//2]:,}")
    for window in WINDOWS:
        over = sum(1 for value in values if value > window)
        print(f"  over {window:>5,} tokens: {over:>3}  ({over / len(values):.1%})")


def main_measure() -> int:
    tokenizer = load_tokenizer()
    print("tokenizer: Laya multilingual, vocab", tokenizer.vocab_size)

    files = per_file(tokenizer)
    report("EVIDENCE FILES (whole file)", [tokens for _, tokens, _ in files])
    print("\n  largest files:")
    for file_id, tokens, size in sorted(files, key=lambda item: -item[1])[:12]:
        print(f"    {file_id:12} {tokens:>9,} tokens  {size / 1024:>8.1f} KiB")
    biggest = max(tokens for _, tokens, _ in files)
    print(f"\n  => every single file fits in 8,192 tokens: {biggest <= 8192}  (max {biggest:,})")

    cases = resolve.load_cases("deletion_requests.csv")
    records = evidence.load_records()
    observe.set_file_weights(records)
    captures = observe.load_captures()
    per = per_case(tokenizer, cases, records, captures)
    report("INTENT (state = the request text)", [row[1] for row in per])
    report("BIND (state + one question per candidate)", [row[2] for row in per])
    report("JUDGE (state = the record list)", [row[3] for row in per])
    print("\n  largest bind prompts:")
    for case_id, _, bind_tokens, _ in sorted(per, key=lambda item: -item[2])[:8]:
        print(f"    {case_id:12} {bind_tokens:>7,} tokens")
    print("\n  largest judge prompts:")
    for case_id, _, _, judge_tokens in sorted(per, key=lambda item: -item[3])[:8]:
        print(f"    {case_id:12} {judge_tokens:>7,} tokens")
    return 0


if __name__ == "__main__":
    raise SystemExit(main_measure())
