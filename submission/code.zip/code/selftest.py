#!/usr/bin/env python3
"""Three evaluation cases written by us.

They are not part of the supplied dataset. Each one is a small synthetic
scenario fed through the *real* observation, policy and planning code, so a
failure here is a failure of the shipped logic rather than of a fixture.

Run:
    python -X utf8 code/selftest.py
"""

from __future__ import annotations

import json
import sys

try:
    from . import evidence, identity, observe, plan
except ImportError:  # running as a plain script
    import evidence
    import identity
    import observe
    import plan

SUBJECT = identity.Subject(
    user_id="user_900",
    emails={"casey.nolan@example.com"},
    phones={"15551234567"},
    hashes={"a" * 64},
)

def record(resource_id: str, system: str, captured_at: str, **attributes) -> evidence.Record:
    attributes["resource_id"] = resource_id
    return evidence.Record(
        file_id="evidence_900",
        captured_at=captured_at,
        system=system,
        resource_id=resource_id,
        text=json.dumps(attributes),
        attributes={key: value for key, value in attributes.items() if value is not None},
    )


def run_case(case: dict) -> tuple[bool, str]:
    """Feed one synthetic scenario through observe -> policy -> plan."""
    records = case["records"]
    observations = []
    for resource_id in dict.fromkeys(r.resource_id for r in records):
        group = [r for r in records if r.resource_id == resource_id]
        observations.append(
            observe.observed_state(
                resource_id, group[0].system, group, SUBJECT, [], case["audit_at"]
            )
        )
    status, steps = plan.plan(observations)
    ok = status == case["expect_status"] and steps == case["expect_steps"]
    detail = "" if ok else f"status={status} steps={json.dumps(steps, ensure_ascii=False)}"
    return ok, detail


CASES = [
    {
        "name": "tombstone keeps only the stable reference",
        "question": (
            "An account tombstone that has already been stripped of name, "
            "email, phone and email hash must verify as redacted, not as a "
            "remaining record."
        ),
        "audit_at": "2026-10-01T12:00:00Z",
        "records": [
            record(
                "tombstone_900",
                "identity_service",
                "2026-09-01T12:00:00Z",
                subject_reference="user_900",
                account_status="DELETED",
                name=None,
                email=None,
                phone=None,
                email_hash=None,
            )
        ],
        "expect_status": "COMPLETE",
        "expect_steps": [
            {
                "step_no": 1,
                "phase": "VERIFICATION",
                "system_id": "identity_service",
                "resource_id": "tombstone_900",
                "operation": "VERIFY_RECORD_REDACTED",
                "state": "REDACTED",
                "evidence_id": "evidence_900",
            }
        ],
    },
    {
        "name": "support message still exposes a direct identifier",
        "question": (
            "A retained support conversation that still carries the subject's "
            "email must be reported as exposed PII and redacted, and the "
            "ownership verification must still expect the record to exist."
        ),
        "audit_at": "2026-10-01T12:00:00Z",
        "records": [
            record(
                "support_900",
                "support_platform",
                "2026-09-01T12:00:00Z",
                requester_email="casey.nolan@example.com",
                message_text="Customer asked about the delivery window.",
            )
        ],
        "expect_status": "INCOMPLETE",
        "expect_steps": [
            {
                "step_no": 1,
                "phase": "FINDING",
                "system_id": "support_platform",
                "resource_id": "support_900",
                "operation": "REPORT_EXPOSED_PII",
                "state": "PRESENT",
                "evidence_id": "evidence_900",
            },
            {
                "step_no": 2,
                "phase": "REMEDIATION",
                "system_id": "support_platform",
                "resource_id": "support_900",
                "operation": "REDACT_RECORD",
                "state": "REDACTED",
                "evidence_id": "",
            },
            {
                "step_no": 3,
                "phase": "VERIFICATION",
                "system_id": "support_platform",
                "resource_id": "support_900",
                "operation": "VERIFY_RECORD_REDACTED",
                "state": "REDACTED",
                "evidence_id": "",
            },
        ],
    },
    {
        "name": "an active flow outranks an ancestor backup",
        "question": (
            "When a restorable backup and a live connector both hold the "
            "subject's data, both are reported, the flow is disabled before "
            "the restore path is blocked, and neither verification cites "
            "evidence because the work has not happened yet."
        ),
        "audit_at": "2026-10-01T12:00:00Z",
        "records": [
            record(
                "backup_900",
                "backup_service",
                "2026-09-01T12:00:00Z",
                customer_email="casey.nolan@example.com",
                archive_key="archive/customer-data/backup_900.tar.zst",
                restore_allowed=1,
            ),
            record(
                "data_flow_900",
                "integration_service",
                "2026-09-02T12:00:00Z",
                customer_email="casey.nolan@example.com",
                connector_name="crm_sync",
                enabled="true",
            ),
        ],
        "expect_status": "INCOMPLETE",
        "expect_steps": [
            {
                "step_no": 1,
                "phase": "FINDING",
                "system_id": "integration_service",
                "resource_id": "data_flow_900",
                "operation": "REPORT_ACTIVE_DATA_FLOW",
                "state": "ACTIVE",
                "evidence_id": "evidence_900",
            },
            {
                "step_no": 2,
                "phase": "FINDING",
                "system_id": "backup_service",
                "resource_id": "backup_900",
                "operation": "REPORT_RESTORE_RISK",
                "state": "ACTIVE",
                "evidence_id": "evidence_900",
            },
            {
                "step_no": 3,
                "phase": "REMEDIATION",
                "system_id": "integration_service",
                "resource_id": "data_flow_900",
                "operation": "DISABLE_DATA_FLOW",
                "state": "DISABLED",
                "evidence_id": "",
            },
            {
                "step_no": 4,
                "phase": "REMEDIATION",
                "system_id": "backup_service",
                "resource_id": "backup_900",
                "operation": "BLOCK_RESTORE",
                "state": "BLOCKED",
                "evidence_id": "",
            },
            {
                "step_no": 5,
                "phase": "VERIFICATION",
                "system_id": "integration_service",
                "resource_id": "data_flow_900",
                "operation": "VERIFY_DATA_FLOW_DISABLED",
                "state": "DISABLED",
                "evidence_id": "",
            },
            {
                "step_no": 6,
                "phase": "VERIFICATION",
                "system_id": "backup_service",
                "resource_id": "backup_900",
                "operation": "VERIFY_RESTORE_BLOCKED",
                "state": "BLOCKED",
                "evidence_id": "",
            },
        ],
    },
]


def main() -> int:
    passed = 0
    for case in CASES:
        ok, detail = run_case(case)
        passed += ok
        print(f"[{'PASS' if ok else 'FAIL'}] {case['name']}")
        if detail:
            print(f"       {detail}")
            print(f"       expected {json.dumps(case['expect_steps'], ensure_ascii=False)}")
    print(f"\n{passed}/{len(CASES)} participant-authored evaluation cases pass")
    return 0 if passed == len(CASES) else 1


if __name__ == "__main__":
    sys.exit(main())
